const C = require('../../utils/constants.js')
const U = require('../../utils/common.js')

Component({
  properties: {
    todo: { type: Object, value: {} },
    index: { type: Number, value: 0 },
    total: { type: Number, value: 1 }
  },
  data: {
    priorityLabel: '中',
    priorityColor: '#FF9F43',
    dueText: '',
    overdue: false
  },
  observers: {
    'todo': function (todo) {
      if (!todo || !todo.id) return
      const p = C.PRIORITIES.filter(function (x) { return x.key === todo.priority })[0] || C.PRIORITIES[1]
      const today = U.dateStr(new Date())
      let dueText = ''
      let overdue = false
      if (todo.due) {
        if (todo.due === today) dueText = '今天'
        else if (todo.due === U.addDays(today, 1)) dueText = '明天'
        else if (todo.due === U.addDays(today, -1)) dueText = '昨天'
        else dueText = U.fmtDateCN(todo.due)
        if (!todo.done && todo.due < today) {
          overdue = true
          dueText = '已逾期'
        }
      }
      this.setData({
        priorityLabel: p.label,
        priorityColor: p.color,
        dueText: dueText,
        overdue: overdue
      })
    }
  },
  methods: {
    onToggle() {
      this.triggerEvent('toggle', { id: this.data.todo.id })
    },
    onRemove() {
      this.triggerEvent('remove', { id: this.data.todo.id })
    },
    onUp() {
      this.triggerEvent('up', { id: this.data.todo.id })
    },
    onDown() {
      this.triggerEvent('down', { id: this.data.todo.id })
    }
  }
})
