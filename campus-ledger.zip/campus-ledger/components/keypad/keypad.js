Component({
  properties: {
    value: { type: String, value: '' } // 当前金额字符串，如 "12.5"
  },
  data: {
    keys: ['1', '2', '3', '4', '5', '6', '7', '8', '9', '.', '0', 'del']
  },
  methods: {
    onTap(e) {
      const k = e.currentTarget.dataset.k
      let v = this.data.value || ''
      if (k === 'del') {
        v = v.slice(0, -1)
      } else if (k === '.') {
        if (v.indexOf('.') >= 0) return
        v = v === '' ? '0.' : v + '.'
      } else {
        if (v === '0') {
          v = k
        } else {
          const dot = v.indexOf('.')
          if (dot >= 0 && v.length - dot > 2) return // 最多两位小数
          if (v.replace('.', '').length >= 9) return // 最长 9 位
          v += k
        }
      }
      this.triggerEvent('input', { value: v })
    },
    onSave() {
      this.triggerEvent('save', { value: this.data.value })
    }
  }
})
