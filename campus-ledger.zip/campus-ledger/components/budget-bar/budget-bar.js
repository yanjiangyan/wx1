Component({
  properties: {
    spent: { type: Number, value: 0 }, // 已用（分）
    total: { type: Number, value: 0 }, // 预算（分）
    height: { type: Number, value: 16 }, // 高度（rpx）
    showText: { type: Boolean, value: true }
  },
  data: {
    percent: 0,
    rawPercent: 0,
    color: '#2B7CFF',
    remain: 0,
    over: false
  },
  observers: {
    'spent, total': function (spent, total) {
      const pct = total > 0 ? (spent / total) * 100 : 0
      let color = '#2B7CFF'
      if (pct >= 90) color = '#FF5B5B' // 90% 变红
      else if (pct >= 70) color = '#FF9F43' // 70% 变橙
      this.setData({
        percent: Math.min(Math.round(pct * 10) / 10, 100),
        rawPercent: Math.round(pct * 10) / 10,
        color: color,
        remain: total - spent,
        over: spent > total
      })
    }
  }
})
