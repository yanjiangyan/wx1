const db = require('../../utils/store.js')
const U = require('../../utils/common.js')

Page({
  data: {
    ym: '',
    summary: { expense: 0, income: 0, balance: 0, count: 0 },
    summaryStr: { expense: '0.00', income: '0.00', balance: '0.00' },
    weekDays: ['一', '二', '三', '四', '五', '六', '日'],
    cells: [],
    today: '',
    selectedDate: '',
    bills: [],
    dayExpenseStr: '0.00',
    // 筛选
    filterVisible: false,
    filter: { keyword: '', categoryId: '', minStr: '', maxStr: '', bookId: '' },
    filterDraft: { keyword: '', categoryId: '', minStr: '', maxStr: '', bookId: '' },
    filterActive: false,
    expenseCats: [],
    books: [],
    // 批量管理
    batchMode: false,
    selectedIds: {},
    selectedCount: 0,
    catPickerVisible: false,
    catPickerCats: []
  },

  onLoad() {
    this.setData({ today: U.dateStr(new Date()) })
  },

  onShow() {
    const today = U.dateStr(new Date())
    this.setData({
      ym: U.monthStr(new Date()),
      selectedDate: today,
      filter: { keyword: '', categoryId: '', minStr: '', maxStr: '', bookId: '' },
      filterDraft: { keyword: '', categoryId: '', minStr: '', maxStr: '', bookId: '' },
      filterActive: false,
      batchMode: false,
      selectedIds: {},
      selectedCount: 0
    })
    this.reload()
  },

  reload() {
    const ym = this.data.ym
    const summary = db.monthSummary(ym)
    const dailyMap = db.dailyExpenseMap(ym)
    const incomeMap = db.dailyIncomeMap(ym)
    const cells = this.buildCalendar(ym, dailyMap, incomeMap)
    const bills = this.loadBills()
    this.setData({
      summary: summary,
      summaryStr: {
        expense: U.fmtMoney(summary.expense),
        income: U.fmtMoney(summary.income),
        balance: U.fmtMoney(summary.balance)
      },
      cells: cells,
      bills: bills,
      dayExpenseStr: U.fmtMoney(dailyMap[this.data.selectedDate] || 0),
      expenseCats: db.listCategories('expense').filter(function (c) { return c.enabled }),
      books: db.listBooks()
    })
  },

  buildCalendar(ym, dailyMap, incomeMap) {
    const dim = U.daysInMonth(ym)
    const first = U.parseDate(ym + '-01')
    const offset = (first.getDay() + 6) % 7 // 周一为首日
    const cells = []
    for (let i = 0; i < offset; i++) cells.push({ empty: true })
    for (let d = 1; d <= dim; d++) {
      const ds = ym + '-' + U.pad2(d)
      const expense = dailyMap[ds] || 0
      const income = (incomeMap && incomeMap[ds]) || 0
      cells.push({
        day: d,
        date: ds,
        expense: expense,
        income: income,
        expenseText: expense > 0 ? String(Math.round(expense / 100)) : '',
        incomeText: income > 0 ? String(Math.round(income / 100)) : '',
        isToday: ds === this.data.today,
        future: ds > this.data.today
      })
    }
    return cells
  },

  decorate(bill) {
    const cat = bill.categoryId ? db.getCategory(bill.categoryId) : null
    const book = db.getBook(bill.bookId)
    const row = Object.assign({}, bill, {
      catName: cat ? cat.name : (bill.type === 'transfer' ? '转账' : '未分类'),
      icon: cat ? cat.icon : 'refund',
      color: cat ? cat.color : '#6E7280',
      bookName: book ? book.name : '',
      time: U.timeOf(bill.createdAt || Date.now()),
      fromName: bill.fromBookId ? (db.getBook(bill.fromBookId) || {}).name : '',
      toName: bill.toBookId ? (db.getBook(bill.toBookId) || {}).name : '',
      amountStr: U.fmtMoney(bill.amount)
    })
    return row
  },

  loadBills() {
    let list
    if (this.data.filterActive) {
      const f = this.data.filter
      list = db.listBills({
        month: this.data.ym,
        categoryId: f.categoryId || undefined,
        min: f.minStr ? U.yuanToFen(f.minStr) : undefined,
        max: f.maxStr ? U.yuanToFen(f.maxStr) : undefined,
        keyword: f.keyword || undefined,
        bookId: f.bookId || undefined
      })
    } else {
      list = db.listBills({ date: this.data.selectedDate })
    }
    return list.map(this.decorate, this)
  },

  prevMonth() {
    this.setData({ ym: U.addMonths(this.data.ym, -1), selectedDate: '' })
    this.reload()
  },

  nextMonth() {
    const next = U.addMonths(this.data.ym, 1)
    if (next > U.monthStr(new Date())) {
      wx.showToast({ title: '不能超过本月', icon: 'none' })
      return
    }
    this.setData({ ym: next, selectedDate: '' })
    this.reload()
  },

  selectDay(e) {
    const d = e.currentTarget.dataset.d
    if (!d) return
    this.setData({ selectedDate: d, filterActive: false })
    this.reload()
  },

  goRecord() {
    wx.navigateTo({ url: '/pages/record/record' })
  },

  openBill(e) {
    if (this.data.batchMode) {
      this.toggleSelect(e)
      return
    }
    wx.navigateTo({ url: '/pages/bill-detail/bill-detail?id=' + e.currentTarget.dataset.id })
  },

  /* ---------- 筛选 ---------- */
  openFilter() {
    this.setData({
      filterVisible: true,
      filterDraft: Object.assign({}, this.data.filter)
    })
  },

  closeFilter() {
    this.setData({ filterVisible: false })
  },

  onFilterKeyword(e) {
    this.setData({ 'filterDraft.keyword': e.detail.value })
  },

  onFilterMin(e) {
    this.setData({ 'filterDraft.minStr': e.detail.value })
  },

  onFilterMax(e) {
    this.setData({ 'filterDraft.maxStr': e.detail.value })
  },

  pickFilterCat(e) {
    this.setData({ 'filterDraft.categoryId': e.currentTarget.dataset.id || '' })
  },

  pickFilterBook(e) {
    this.setData({ 'filterDraft.bookId': e.currentTarget.dataset.id || '' })
  },

  applyFilter() {
    const f = this.data.filterDraft
    const active = !!(f.keyword || f.categoryId || f.minStr || f.maxStr || f.bookId)
    this.setData({ filter: Object.assign({}, f), filterActive: active, filterVisible: false })
    this.reload()
  },

  resetFilter() {
    this.setData({
      filterDraft: { keyword: '', categoryId: '', minStr: '', maxStr: '', bookId: '' },
      filter: { keyword: '', categoryId: '', minStr: '', maxStr: '', bookId: '' },
      filterActive: false,
      filterVisible: false
    })
    this.reload()
  },

  /* ---------- 批量管理 ---------- */
  toggleBatch() {
    this.setData({ batchMode: !this.data.batchMode, selectedIds: {}, selectedCount: 0 })
  },

  toggleSelect(e) {
    const id = e.currentTarget.dataset.id
    const selected = Object.assign({}, this.data.selectedIds)
    if (selected[id]) delete selected[id]
    else selected[id] = true
    this.setData({ selectedIds: selected, selectedCount: Object.keys(selected).length })
  },

  toggleSelectAll() {
    const all = {}
    if (this.data.selectedCount < this.data.bills.length) {
      this.data.bills.forEach(function (b) { all[b.id] = true })
    }
    this.setData({ selectedIds: all, selectedCount: Object.keys(all).length })
  },

  batchDelete() {
    const ids = Object.keys(this.data.selectedIds)
    if (!ids.length) {
      wx.showToast({ title: '请先选择账单', icon: 'none' })
      return
    }
    wx.showModal({
      title: '批量删除',
      content: '确定删除选中的 ' + ids.length + ' 笔账单吗？删除后不可恢复。',
      confirmText: '删除',
      confirmColor: '#F5483B',
      success: (res) => {
        if (res.confirm) {
          db.deleteBills(ids)
          this.setData({ selectedIds: {}, selectedCount: 0 })
          this.reload()
          wx.showToast({ title: '已删除', icon: 'success' })
        }
      }
    })
  },

  openCatPicker() {
    const ids = Object.keys(this.data.selectedIds)
    if (!ids.length) {
      wx.showToast({ title: '请先选择账单', icon: 'none' })
      return
    }
    this.setData({
      catPickerVisible: true,
      catPickerCats: db.listCategories('expense').filter(function (c) { return c.enabled })
    })
  },

  closeCatPicker() {
    this.setData({ catPickerVisible: false })
  },

  chooseCat(e) {
    const catId = e.currentTarget.dataset.id
    const ids = Object.keys(this.data.selectedIds)
    db.updateBillsCategory(ids, catId)
    this.setData({ catPickerVisible: false, selectedIds: {}, selectedCount: 0 })
    this.reload()
    wx.showToast({ title: '已修改', icon: 'success' })
  }
})
