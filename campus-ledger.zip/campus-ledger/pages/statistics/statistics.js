const db = require('../../utils/store.js')
const U = require('../../utils/common.js')
const charts = require('../../utils/charts.js')

Page({
  data: {
    ym: '',
    canNext: false,
    summaryStr: { expense: '0.00', income: '0.00', balance: '0.00' },
    billCount: 0,
    pieItems: [],
    trend: [],
    top5: [],
    avgCur: 0,
    avgPrev: 0,
    maxDayText: '',
    week: {
      curStr: '0.00', prevStr: '0.00', diffStr: '0.00',
      down: true, top3: [], budgetPct: 0, rangeText: ''
    },
    monthReport: {
      incomeStr: '0.00', expenseStr: '0.00', balanceStr: '0.00',
      rate: 0, topName: '-', topPct: 0, advice: ''
    }
  },

  onLoad() {
    this.setData({ ym: U.monthStr(new Date()), canNext: false })
  },

  onShow() {
    this.load()
  },

  onReady() {
    this.initCanvas()
  },

  initCanvas() {
    const q = wx.createSelectorQuery()
    q.select('#pieCanvas').fields({ node: true, size: true })
    q.select('#lineCanvas').fields({ node: true, size: true })
    q.select('#cmpCanvas').fields({ node: true, size: true })
    q.exec((res) => {
      this._canvases = {}
      const ids = ['pieCanvas', 'lineCanvas', 'cmpCanvas']
      res.forEach(function (r, i) {
        if (r && r.node) {
          this._canvases[ids[i]] = {
            canvas: r.node,
            ctx: r.node.getContext('2d'),
            w: r.width,
            h: r.height
          }
        }
      }, this)
      this.drawAll()
    })
  },

  drawAll() {
    if (!this._canvases) return
    const c = this._canvases
    if (c.pieCanvas) {
      charts.drawPie(c.pieCanvas.canvas, c.pieCanvas.ctx, c.pieCanvas.w, c.pieCanvas.h, this.data.pieItems)
    }
    if (c.lineCanvas) {
      charts.drawLine(c.lineCanvas.canvas, c.lineCanvas.ctx, c.lineCanvas.w, c.lineCanvas.h, this.data.trend)
    }
    if (c.cmpCanvas) {
      charts.drawCompare(c.cmpCanvas.canvas, c.cmpCanvas.ctx, c.cmpCanvas.w, c.cmpCanvas.h, this.data.avgCur, this.data.avgPrev)
    }
  },

  load() {
    const ym = this.data.ym
    const curYm = U.monthStr(new Date())
    const summary = db.monthSummary(ym)
    const all = db.categoryTotals(ym, 'expense')
    const catCounts = db.categoryCounts(ym, 'expense')
    const pieItems = all.slice(0, 8)
    const trend = db.trendExpense(6)
    const top5 = all.slice(0, 5).map(function (x) {
      return {
        id: x.id,
        name: x.name,
        icon: x.icon,
        color: x.color || '#2B7CFF',
        amount: x.amount,
        amountStr: U.fmtMoney(x.amount),
        count: catCounts[x.id] || 0,
        pct: summary.expense > 0 ? Math.round((x.amount / summary.expense) * 1000) / 10 : 0
      }
    })

    // 日均消费
    const isCur = ym === curYm
    const days = isCur ? new Date().getDate() : U.daysInMonth(ym)
    const avgCur = days > 0 ? Math.round(summary.expense / days) : 0
    const prevYm = U.addMonths(ym, -1)
    const prevSummary = db.monthSummary(prevYm)
    const avgPrev = Math.round(prevSummary.expense / U.daysInMonth(prevYm))

    // 最高单日（节假日波动标注）
    const dailyMap = db.dailyExpenseMap(ym)
    let maxDay = ''
    let maxVal = 0
    Object.keys(dailyMap).forEach(function (d) {
      if (dailyMap[d] > maxVal) {
        maxVal = dailyMap[d]
        maxDay = d
      }
    })

    // 周报（本周一至今天）
    const wc = db.weekCompare()
    const top3 = db.weekTopCategories()
    const budget = db.effectiveBudget(ym)
    const weekBudgetPct = budget.total > 0 ? Math.min(100, Math.round((wc.cur / budget.total) * 100)) : 0
    const diff = wc.cur - wc.prev

    // 月报与建议
    const rate = summary.income > 0 ? Math.round((summary.balance / summary.income) * 1000) / 10 : 0
    const topName = all.length ? all[0].name : '-'
    const topPct = all.length && summary.expense > 0 ? Math.round((all[0].amount / summary.expense) * 1000) / 10 : 0
    let advice = ''
    if (summary.balance < 0) {
      advice = '本月支出超过收入，建议优先削减购物与娱乐类非必需支出，避免月底超支。'
    } else if (rate < 10) {
      advice = '储蓄率偏低，可尝试为餐饮设置分类预算，减少外卖与奶茶频次。'
    } else if (topPct > 40) {
      advice = topName + '占比 ' + topPct + '%，是当前最大开支项，建议重点复盘此类消费。'
    } else {
      advice = '收支结构健康，保持记账习惯，可考虑将结余转入储蓄目标。'
    }

    this.setData({
      canNext: ym < curYm,
      summaryStr: {
        expense: U.fmtMoney(summary.expense),
        income: U.fmtMoney(summary.income),
        balance: U.fmtMoney(summary.balance)
      },
      billCount: summary.count,
      pieItems: pieItems,
      trend: trend,
      top5: top5,
      avgCur: avgCur,
      avgPrev: avgPrev,
      maxDayText: maxDay ? '最高单日：' + U.fmtDateCN(maxDay) + ' ¥' + U.fmtMoney(maxVal) + '（节假日波动较大属正常）' : '',
      week: {
        curStr: U.fmtMoney(wc.cur),
        prevStr: U.fmtMoney(wc.prev),
        diffStr: U.fmtMoney(Math.abs(diff)),
        down: diff <= 0,
        top3: top3,
        budgetPct: weekBudgetPct,
        rangeText: U.fmtDateCN(wc.monday) + ' 起'
      },
      monthReport: {
        incomeStr: U.fmtMoney(summary.income),
        expenseStr: U.fmtMoney(summary.expense),
        balanceStr: U.fmtMoney(summary.balance),
        rate: rate,
        topName: topName,
        topPct: topPct,
        advice: advice
      }
    })

    this.drawAll()
  },

  prevMonth() {
    this.setData({ ym: U.addMonths(this.data.ym, -1) })
    this.load()
  },

  nextMonth() {
    if (!this.data.canNext) {
      wx.showToast({ title: '已经是最新月份', icon: 'none' })
      return
    }
    this.setData({ ym: U.addMonths(this.data.ym, 1) })
    this.load()
  },

  onShareAppMessage() {
    return {
      title: '我的消费周报：本周支出 ¥' + this.data.week.curStr,
      path: '/pages/statistics/statistics'
    }
  }
})
