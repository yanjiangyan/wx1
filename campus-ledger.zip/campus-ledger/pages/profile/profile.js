const db = require('../../utils/store.js')
const U = require('../../utils/common.js')

Page({
  data: {
    profile: {},
    totalStat: { billCount: 0, dayCount: 0 },
    booksCount: 0,
    currentBook: {},
    allowanceModal: false,
    allowanceDraft: '',
    nicknameModal: false,
    nicknameDraft: '',
    aboutVisible: false,
    version: '1.0.0'
  },

  onShow() {
    this.load()
  },

  load() {
    const profile = db.getProfile()
    this.setData({
      profile: profile,
      totalStat: db.totalStat(),
      booksCount: db.listBooks().length,
      currentBook: db.getBook(db.currentBookId())
    })
  },

  openAllowance() {
    this.setData({ allowanceModal: true, allowanceDraft: U.fenToYuanStr(this.data.profile.monthlyAllowance || 0) })
  },

  closeAllowance() {
    this.setData({ allowanceModal: false })
  },

  onAllowanceDraft(e) {
    this.setData({ allowanceDraft: e.detail.value })
  },

  saveAllowance() {
    const fen = U.yuanToFen(this.data.allowanceDraft)
    if (fen <= 0) {
      wx.showToast({ title: '请输入有效金额', icon: 'none' })
      return
    }
    db.saveProfile({ monthlyAllowance: fen })
    this.setData({ allowanceModal: false })
    this.load()
    wx.showToast({ title: '已保存', icon: 'success' })
  },

  openNickname() {
    this.setData({ nicknameModal: true, nicknameDraft: this.data.profile.nickname || '' })
  },

  closeNickname() {
    this.setData({ nicknameModal: false })
  },

  onNicknameDraft(e) {
    this.setData({ nicknameDraft: e.detail.value })
  },

  saveNickname() {
    const name = (this.data.nicknameDraft || '').trim()
    if (!name) {
      wx.showToast({ title: '请输入昵称', icon: 'none' })
      return
    }
    db.saveProfile({ nickname: name })
    this.setData({ nicknameModal: false })
    this.load()
  },

  goBudget() {
    wx.navigateTo({ url: '/pages/budget/budget' })
  },

  goBooks() {
    wx.navigateTo({ url: '/pages/books/books' })
  },

  goAA() {
    wx.navigateTo({ url: '/pages/aa/aa' })
  },

  goSavings() {
    wx.navigateTo({ url: '/pages/savings/savings' })
  },

  fillDemoData() {
    wx.showModal({
      title: '填充演示数据',
      content: '将生成近 6 个月的模拟账单（含每月生活费收入），便于体验统计报表。重复填充会累积数据，确定继续吗？',
      confirmText: '填充',
      confirmColor: '#2B7CFF',
      success: (res) => {
        if (!res.confirm) return
        db.seedDemoData()
        this.load()
        wx.showToast({ title: '已填充演示数据', icon: 'success' })
      }
    })
  },

  openAbout() {
    this.setData({ aboutVisible: true })
  },

  closeAbout() {
    this.setData({ aboutVisible: false })
  },

  clearData() {
    wx.showModal({
      title: '清空所有数据',
      content: '将删除全部账单、预算、待办、储蓄目标等数据，并恢复为初始预设，且不可恢复，确定继续吗？',
      confirmText: '继续',
      confirmColor: '#FF5B5B',
      success: (res) => {
        if (!res.confirm) return
        wx.showModal({
          title: '再次确认',
          content: '清空后数据无法找回，确定清空吗？',
          confirmText: '确认清空',
          confirmColor: '#FF5B5B',
          success: (res2) => {
            if (res2.confirm) {
              db.clearAll()
              wx.reLaunch({ url: '/pages/index/index' })
            }
          }
        })
      }
    })
  }
})
