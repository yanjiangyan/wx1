const db = require('../../utils/store.js')
const U = require('../../utils/common.js')

Page({
  data: {
    books: [],
    currentId: '',
    addModal: false,
    editModal: false,
    editingId: '',
    bookName: '',
    bookIcon: '📒',
    emojis: ['👛', '📒', '🏆', '💼', '❤️', '🎓', '💰', '📕', '🎒', '🏦', '✈️', '🎮']
  },

  onShow() {
    this.load()
  },

  load() {
    const currentId = db.currentBookId()
    this.setData({
      currentId: currentId,
      books: db.listBooks().map(function (b) {
        return {
          id: b.id,
          name: b.name,
          icon: b.icon,
          isDefault: !!b.isDefault,
          count: db.bookBillCount(b.id)
        }
      })
    })
  },

  selectBook(e) {
    const id = e.currentTarget.dataset.id
    db.setCurrentBook(id)
    this.load()
    wx.showToast({ title: '已切换账本', icon: 'none' })
  },

  openAdd() {
    this.setData({ addModal: true, bookName: '', bookIcon: '📒' })
  },

  closeAdd() {
    this.setData({ addModal: false })
  },

  closeEdit() {
    this.setData({ editModal: false })
  },

  closeModal() {
    this.setData({ addModal: false, editModal: false })
  },

  saveBook() {
    if (this.data.addModal) this.saveAdd()
    else this.saveEdit()
  },

  onNameInput(e) {
    this.setData({ bookName: e.detail.value })
  },

  chooseIcon(e) {
    this.setData({ bookIcon: e.currentTarget.dataset.e })
  },

  saveAdd() {
    const name = (this.data.bookName || '').trim()
    if (!name) {
      wx.showToast({ title: '请输入账本名称', icon: 'none' })
      return
    }
    db.addBook(name, this.data.bookIcon)
    this.setData({ addModal: false })
    this.load()
    wx.showToast({ title: '已创建', icon: 'success' })
  },

  openEdit(e) {
    const id = e.currentTarget.dataset.id
    const book = this.data.books.filter(function (b) { return b.id === id })[0]
    this.setData({ editModal: true, editingId: id, bookName: book.name, bookIcon: book.icon })
  },

  closeEdit() {
    this.setData({ editModal: false })
  },

  saveEdit() {
    const name = (this.data.bookName || '').trim()
    if (!name) {
      wx.showToast({ title: '请输入账本名称', icon: 'none' })
      return
    }
    db.updateBook(this.data.editingId, { name: name, icon: this.data.bookIcon })
    this.setData({ editModal: false })
    this.load()
    wx.showToast({ title: '已保存', icon: 'success' })
  },

  deleteBook(e) {
    const id = e.currentTarget.dataset.id
    const book = this.data.books.filter(function (b) { return b.id === id })[0]
    if (book.isDefault) {
      wx.showToast({ title: '默认账本不可删除', icon: 'none' })
      return
    }
    wx.showModal({
      title: '删除账本',
      content: '「' + book.name + '」下有 ' + book.count + ' 笔账单，删除后账单将转移到默认账本，确定删除吗？',
      confirmText: '删除',
      confirmColor: '#F5483B',
      success: (res) => {
        if (res.confirm) {
          const r = db.deleteBook(id)
          if (r.ok) {
            this.load()
            wx.showToast({ title: '已删除', icon: 'success' })
          } else {
            wx.showToast({ title: r.msg, icon: 'none' })
          }
        }
      }
    })
  }
})
