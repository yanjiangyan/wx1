const db = require('../../utils/store.js')
const U = require('../../utils/common.js')
const C = require('../../utils/constants.js')

Page({
  data: {
    greeting: '',
    dateCN: '',
    weekday: '',
    ym: '',
    budgetTotal: 0,
    monthSpent: 0,
    monthExpenseStr: '0.00',
    monthIncomeStr: '0.00',
    monthRemainStr: '0.00',
    monthOver: false,
    todayExpenseStr: '0.00',
    todayIncomeStr: '0.00',
    todayCount: 0,
    recentBills: [],
    todos: [],
    quickCats: [],
    pop: false,
    quickModal: false,
    quickCat: {},
    quickAmount: '',
    todoInput: '',
    todoPriority: 'mid',
    dueCycleIndex: 0,
    dueLabels: ['截止: 无', '截止: 今天', '截止: 明天', '截止: 后天']
  },

  onShow() {
    this.loadAll()
    // 记账保存成功后的首页数字更新动画
    if (getApp().globalData.justSaved) {
      getApp().globalData.justSaved = false
      this.setData({ pop: true })
      setTimeout(() => this.setData({ pop: false }), 700)
    }
  },

  loadAll() {
    const now = new Date()
    const today = U.dateStr(now)
    const ym = U.monthStr(now)
    const summary = db.monthSummary(ym)
    const budget = db.effectiveBudget(ym)
    const remain = budget.total - summary.expense

    const todayBills = db.listBills({ date: today })
    let exp = 0
    let inc = 0
    todayBills.forEach(function (b) {
      if (b.type === 'expense') exp += b.amount
      else if (b.type === 'income') inc += b.amount
    })

    // 未完成待办置前
    const todos = db.listTodos().slice().sort(function (a, b) {
      if (a.done !== b.done) return a.done ? 1 : -1
      return 0
    })

    // 校园快捷记账分类
    const cats = db.listCategories('expense')
    const quickCats = []
    C.QUICK_CATEGORIES.forEach(function (name) {
      const hit = cats.filter(function (c) { return c.name === name })[0]
      if (hit) quickCats.push(hit)
    })

    this.setData({
      greeting: U.greeting(),
      dateCN: U.fmtDateCN(today),
      weekday: U.weekdayCN(today),
      ym: ym,
      budgetTotal: budget.total,
      monthSpent: summary.expense,
      monthExpenseStr: U.fmtMoney(summary.expense),
      monthIncomeStr: U.fmtMoney(summary.income),
      monthRemainStr: U.fmtMoney(Math.abs(remain)),
      monthOver: remain < 0,
      todayExpenseStr: U.fmtMoney(exp),
      todayIncomeStr: U.fmtMoney(inc),
      todayCount: todayBills.filter(function (b) { return b.type !== 'transfer' }).length,
      recentBills: todayBills.slice(0, 4).map(function (b) {
        const cat = b.categoryId ? db.getCategory(b.categoryId) : null
        return {
          id: b.id,
          icon: cat ? cat.icon : 'refund',
          color: cat ? cat.color : '#6E7280',
          name: cat ? cat.name : '转账',
          note: b.note || '',
          amountStr: U.fmtMoney(b.amount),
          type: b.type,
          time: U.timeOf(b.createdAt || Date.now())
        }
      }),
      todos: todos.slice(0, 6),
      quickCats: quickCats
    })
  },

  goRecord() {
    wx.navigateTo({ url: '/pages/record/record' })
  },

  goBills() {
    wx.navigateTo({ url: '/pages/bills/bills' })
  },

  goStatistics() {
    wx.switchTab({ url: '/pages/statistics/statistics' })
  },

  goAA() {
    wx.navigateTo({ url: '/pages/aa/aa' })
  },

  goSavings() {
    wx.navigateTo({ url: '/pages/savings/savings' })
  },

  goBudget() {
    wx.navigateTo({ url: '/pages/budget/budget' })
  },

  /* ---------- 校园快捷记账 ---------- */
  openQuick(e) {
    const id = e.currentTarget.dataset.id
    const cat = this.data.quickCats.filter(function (c) { return c.id === id })[0]
    if (!cat) return
    this.setData({ quickModal: true, quickCat: cat, quickAmount: '' })
  },

  closeQuick() {
    this.setData({ quickModal: false })
  },

  onQuickAmount(e) {
    this.setData({ quickAmount: e.detail.value })
  },

  confirmQuick() {
    const fen = U.yuanToFen(this.data.quickAmount)
    if (fen <= 0) {
      wx.showToast({ title: '请输入金额', icon: 'none' })
      return
    }
    const bookId = db.currentBookId()
    db.addBill({
      type: 'expense',
      amount: fen,
      categoryId: this.data.quickCat.id,
      bookId: bookId,
      note: '',
      date: U.dateStr(new Date())
    })
    this.setData({ quickModal: false, pop: true })
    setTimeout(() => this.setData({ pop: false }), 700)
    this.loadAll()
    wx.showToast({ title: '已记录', icon: 'success' })
  },

  /* ---------- 待办 ---------- */
  onTodoInput(e) {
    this.setData({ todoInput: e.detail.value })
  },

  addTodo() {
    const content = (this.data.todoInput || '').trim()
    if (!content) {
      wx.showToast({ title: '请输入待办内容', icon: 'none' })
      return
    }
    const dueOptions = ['', U.dateStr(new Date()), U.addDays(U.dateStr(new Date()), 1), U.addDays(U.dateStr(new Date()), 2)]
    db.addTodo(content, this.data.todoPriority, dueOptions[this.data.dueCycleIndex])
    this.setData({ todoInput: '' })
    this.loadAll()
  },

  pickPriority(e) {
    this.setData({ todoPriority: e.currentTarget.dataset.p })
  },

  cycleDue() {
    this.setData({ dueCycleIndex: (this.data.dueCycleIndex + 1) % 4 })
  },

  onTodoToggle(e) {
    db.toggleTodo(e.detail.id)
    this.loadAll()
  },

  onTodoRemove(e) {
    db.deleteTodo(e.detail.id)
    this.loadAll()
  },

  onTodoUp(e) {
    db.moveTodo(e.detail.id, -1)
    this.loadAll()
  },

  onTodoDown(e) {
    db.moveTodo(e.detail.id, 1)
    this.loadAll()
  },

  onShareAppMessage() {
    return {
      title: '管好每一分钱，过好每一天',
      path: '/pages/index/index'
    }
  }
})
