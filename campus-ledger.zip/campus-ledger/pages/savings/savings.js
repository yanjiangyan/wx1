const db = require('../../utils/store.js')
const U = require('../../utils/common.js')
const C = require('../../utils/constants.js')

Page({
  data: {
    bars: [],
    monthIncomeStr: '0.00',
    monthExpenseStr: '0.00',
    monthRate: 0,
    ratioAdvice: '',
    goals: [],
    goalModal: false,
    goalName: '',
    goalTarget: '',
    goalMonthly: '',
    goalIcon: '🎯',
    goalEmojis: ['🎯', '💻', '✈️', '📷', '🎸', '📚', '🚲', '🎮', '👟', '🏠'],
    depositModal: false,
    depositGoal: {},
    depositAmount: '',
    ptModal: false,
    ptAmount: '',
    ptType: '家教',
    ptDate: '',
    ptNote: '',
    ptTypes: C.PARTTIME_TYPES,
    ptList: [],
    // 存钱方式（规范：胶囊入口，不同存钱法匹配不同主题色）
    savingsMethods: [
      { name: '52 周存钱法', icon: 'chart', color: '#2B7CFF', desc: '第 1 周存 10 元，之后每周递增 10 元，第 52 周存 520 元。坚持一年可存 13780 元，压力逐周平缓上升，适合有固定生活费结余的同学。' },
      { name: '365 日存钱法', icon: 'calendar', color: '#FF9F43', desc: '每天从 1~365 元中任选一个数字存入，一年最多可存 66795 元。数字可重复选，适合在假期实习、拿到红包时挑大额存入。' },
      { name: '12 存单法', icon: 'bill', color: '#2ECC71', desc: '每月固定存一笔小额定期，存满 12 个月后月月有存款到期，兼顾强制储蓄与流动性，适合目标明确的大额消费（如换电脑）。' },
      { name: '弹性存钱法', icon: 'piggy', color: '#A78BFA', desc: '不设固定金额，月底结余多少存多少。学生党最推荐：配合分类预算先存后花，把「花不完的钱」变成「存下来的钱」。' }
    ]
  },

  onLoad() {
    this.setData({ ptDate: U.dateStr(new Date()) })
  },

  onShow() {
    this.load()
  },

  load() {
    // 近 6 个月收支对比
    const cur = U.monthStr(new Date())
    const bars = []
    for (let i = 5; i >= 0; i--) {
      const ym = U.addMonths(cur, -i)
      const s = db.monthSummary(ym)
      const rate = s.income > 0 ? Math.round((s.balance / s.income) * 1000) / 10 : 0
      bars.push({
        ym: ym,
        income: s.income,
        expense: s.expense,
        rate: rate,
        incomeStr: U.fmtMoney(s.income),
        expenseStr: U.fmtMoney(s.expense),
        maxH: Math.max(120, Math.round((Math.max(s.income, s.expense) / 100)))
      })
    }
    const maxBar = Math.max.apply(null, bars.map(function (b) {
      return Math.max(b.income, b.expense)
    })) || 1
    bars.forEach(function (b) {
      b.incomeH = Math.round((b.income / maxBar) * 200)
      b.expenseH = Math.round((b.expense / maxBar) * 200)
    })

    const curSummary = db.monthSummary(cur)
    const rate = curSummary.income > 0 ? Math.round((curSummary.balance / curSummary.income) * 1000) / 10 : 0
    let advice = ''
    if (curSummary.income === 0) {
      advice = '本月还没有收入记录，记入生活费或兼职收入后可查看储蓄率分析。'
    } else if (rate < 0) {
      advice = '本月入不敷出，建议压缩非必需支出，避免动用到期生活费。'
    } else if (rate < 20) {
      advice = '储蓄率偏低，可设置储蓄目标并开启每月自动划拨，积少成多。'
    } else {
      advice = '储蓄率不错！可将结余划入储蓄目标，为买电脑、旅行等计划做准备。'
    }

    this.setData({
      bars: bars,
      monthIncomeStr: U.fmtMoney(curSummary.income),
      monthExpenseStr: U.fmtMoney(curSummary.expense),
      monthRate: rate,
      ratioAdvice: advice,
      goals: db.listGoals().map(function (g) {
        return {
          id: g.id,
          name: g.name,
          icon: g.icon,
          target: g.target,
          targetStr: U.fmtMoney(g.target),
          saved: g.saved,
          savedStr: U.fmtMoney(g.saved),
          monthly: g.monthly,
          monthlyStr: U.fmtMoney(g.monthly),
          pct: g.target > 0 ? Math.min(100, Math.round((g.saved / g.target) * 1000) / 10) : 0,
          done: g.saved >= g.target
        }
      }),
      ptList: db.listPartTime().map(function (p) {
        return {
          id: p.id,
          amount: p.amount,
          amountStr: U.fmtMoney(p.amount),
          type: p.type,
          date: p.date,
          note: p.note || ''
        }
      })
    })
  },

  /* ---------- 存钱方式 ---------- */
  showMethod(e) {
    const m = this.data.savingsMethods[e.currentTarget.dataset.i]
    wx.showModal({ title: m.name, content: m.desc, showCancel: false, confirmText: '知道了' })
  },

  /* ---------- 储蓄目标 ---------- */
  openGoalModal() {
    this.setData({ goalModal: true, goalName: '', goalTarget: '', goalMonthly: '', goalIcon: '🎯' })
  },

  closeGoalModal() {
    this.setData({ goalModal: false })
  },

  onGoalName(e) {
    this.setData({ goalName: e.detail.value })
  },

  onGoalTarget(e) {
    this.setData({ goalTarget: e.detail.value })
  },

  onGoalMonthly(e) {
    this.setData({ goalMonthly: e.detail.value })
  },

  chooseGoalIcon(e) {
    this.setData({ goalIcon: e.currentTarget.dataset.e })
  },

  saveGoal() {
    const name = (this.data.goalName || '').trim()
    const target = U.yuanToFen(this.data.goalTarget)
    if (!name) {
      wx.showToast({ title: '请输入目标名称', icon: 'none' })
      return
    }
    if (target <= 0) {
      wx.showToast({ title: '请输入目标金额', icon: 'none' })
      return
    }
    db.addGoal(name, target, U.yuanToFen(this.data.goalMonthly), this.data.goalIcon)
    this.setData({ goalModal: false })
    this.load()
    wx.showToast({ title: '已创建目标', icon: 'success' })
  },

  openDeposit(e) {
    const id = e.currentTarget.dataset.id
    const goal = this.data.goals.filter(function (g) { return g.id === id })[0]
    this.setData({ depositModal: true, depositGoal: goal, depositAmount: '' })
  },

  closeDeposit() {
    this.setData({ depositModal: false })
  },

  onDepositAmount(e) {
    this.setData({ depositAmount: e.detail.value })
  },

  confirmDeposit() {
    const fen = U.yuanToFen(this.data.depositAmount)
    if (fen <= 0) {
      wx.showToast({ title: '请输入金额', icon: 'none' })
      return
    }
    db.depositGoal(this.data.depositGoal.id, fen)
    this.setData({ depositModal: false })
    this.load()
    wx.showToast({ title: '已存入', icon: 'success' })
  },

  // 月度划拨（演示「每月自动划拨」）
  monthlyTransfer(e) {
    const id = e.currentTarget.dataset.id
    const goal = this.data.goals.filter(function (g) { return g.id === id })[0]
    if (!goal || goal.monthly <= 0) {
      wx.showToast({ title: '请先设置每月划拨金额', icon: 'none' })
      return
    }
    db.depositGoal(id, goal.monthly)
    this.load()
    wx.showToast({ title: '已划拨 ¥' + goal.monthlyStr, icon: 'success' })
  },

  deleteGoal(e) {
    const id = e.currentTarget.dataset.id
    wx.showModal({
      title: '删除目标',
      content: '确定删除这个储蓄目标吗？',
      confirmText: '删除',
      confirmColor: '#F5483B',
      success: (res) => {
        if (res.confirm) {
          db.deleteGoal(id)
          this.load()
        }
      }
    })
  },

  /* ---------- 兼职收入 ---------- */
  openPtModal() {
    this.setData({ ptModal: true, ptAmount: '', ptType: '家教', ptNote: '', ptDate: U.dateStr(new Date()) })
  },

  closePtModal() {
    this.setData({ ptModal: false })
  },

  onPtAmount(e) {
    this.setData({ ptAmount: e.detail.value })
  },

  pickPtType(e) {
    this.setData({ ptType: e.currentTarget.dataset.t })
  },

  onPtDateChange(e) {
    this.setData({ ptDate: e.detail.value })
  },

  onPtNote(e) {
    this.setData({ ptNote: e.detail.value })
  },

  savePt() {
    const fen = U.yuanToFen(this.data.ptAmount)
    if (fen <= 0) {
      wx.showToast({ title: '请输入金额', icon: 'none' })
      return
    }
    db.addPartTime(fen, this.data.ptType, this.data.ptDate, this.data.ptNote)
    // 同步记一笔收入（兼职分类），保证收支统计一致
    const cat = db.listCategories('income').filter(function (c) { return c.name === '兼职' })[0]
    if (cat) {
      db.addBill({
        type: 'income',
        amount: fen,
        categoryId: cat.id,
        bookId: db.currentBookId(),
        note: '兼职-' + this.data.ptType,
        date: this.data.ptDate
      })
    }
    this.setData({ ptModal: false })
    this.load()
    wx.showToast({ title: '已记录', icon: 'success' })
  },

  deletePt(e) {
    db.deletePartTime(e.currentTarget.dataset.id)
    this.load()
  }
})
