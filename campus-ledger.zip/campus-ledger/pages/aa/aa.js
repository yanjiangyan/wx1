const db = require('../../utils/store.js')
const U = require('../../utils/common.js')

Page({
  data: {
    totalStr: '',
    peopleStr: '2',
    perPersonStr: '0.00',
    remainderStr: '0.00',
    rows: [],
    history: []
  },

  onShow() {
    this.loadHistory()
  },

  onTotalInput(e) {
    this.setData({ totalStr: e.detail.value })
    this.compute()
  },

  onPeopleInput(e) {
    this.setData({ peopleStr: e.detail.value })
    this.compute()
  },

  compute() {
    const total = U.yuanToFen(this.data.totalStr)
    const people = parseInt(this.data.peopleStr, 10) || 0
    if (total <= 0 || people <= 0) {
      this.setData({ perPersonStr: '0.00', remainderStr: '0.00', rows: [] })
      return
    }
    const per = Math.floor(total / people)
    const remainder = total - per * people
    const rows = []
    for (let i = 0; i < people; i++) {
      const isLast = i === people - 1
      rows.push({
        label: '成员 ' + (i + 1) + (isLast && remainder > 0 ? '（含差额）' : ''),
        amountStr: U.fmtMoney(per + (isLast ? remainder : 0))
      })
    }
    this.setData({
      perPersonStr: U.fmtMoney(per),
      remainderStr: U.fmtMoney(remainder),
      rows: rows
    })
  },

  resultText() {
    const total = U.yuanToFen(this.data.totalStr)
    const people = parseInt(this.data.peopleStr, 10) || 0
    if (total <= 0 || people <= 0) return ''
    return '聚餐AA分账：总金额 ¥' + U.fmtMoney(total) + '，' + people + ' 人分摊，每人 ¥' + this.data.perPersonStr +
      (U.yuanToFen(this.data.remainderStr) > 0 ? '（差额 ¥' + this.data.remainderStr + ' 由最后一人承担）' : '')
  },

  copyResult() {
    const text = this.resultText()
    if (!text) {
      wx.showToast({ title: '请先输入金额和人数', icon: 'none' })
      return
    }
    wx.setClipboardData({ data: text })
  },

  saveRecord() {
    const total = U.yuanToFen(this.data.totalStr)
    const people = parseInt(this.data.peopleStr, 10) || 0
    if (total <= 0 || people <= 0) {
      wx.showToast({ title: '请先输入金额和人数', icon: 'none' })
      return
    }
    db.addAA(total, people, Math.floor(total / people), U.dateStr(new Date()))
    this.loadHistory()
    wx.showToast({ title: '已保存记录', icon: 'success' })
  },

  loadHistory() {
    this.setData({
      history: db.listAA().map(function (r) {
        return {
          id: r.id,
          date: r.date,
          totalStr: U.fmtMoney(r.total),
          people: r.people,
          perStr: U.fmtMoney(r.perPerson)
        }
      })
    })
  },

  onShareAppMessage() {
    const text = this.resultText()
    return {
      title: text || '聚餐AA分账工具',
      path: '/pages/aa/aa'
    }
  }
})
