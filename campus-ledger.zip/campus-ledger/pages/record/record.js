const db = require('../../utils/store.js')
const U = require('../../utils/common.js')
const C = require('../../utils/constants.js')

Page({
  data: {
    type: 'expense', // expense | income | transfer
    amount: '',
    commonCats: [],
    allCats: [],
    activeCatId: '',
    note: '',
    date: '',
    today: '',
    yesterday: '',
    beforeY: '',
    books: [],
    book: {},
    bookId: '',
    fromBook: {},
    toBook: {},
    transferFrom: '',
    transferTo: '',
    editingId: '',
    customModal: false,
    customName: '',
    customIcon: 'rice',
    customIcons: C.CUSTOM_ICONS
  },

  onLoad(options) {
    const today = U.dateStr(new Date())
    this.setData({
      today: today,
      yesterday: U.addDays(today, -1),
      beforeY: U.addDays(today, -2),
      date: today
    })
    if (options.id) {
      this.setData({ editingId: options.id })
      wx.setNavigationBarTitle({ title: '编辑账单' })
      this.loadBill(options.id)
    }
  },

  onShow() {
    this.loadCategories()
    this.loadBooks()
  },

  loadBill(id) {
    const b = db.getBill(id)
    if (!b) return
    if (b.type === 'transfer') {
      this.setData({
        type: 'transfer',
        amount: U.fenToYuanStr(b.amount),
        note: b.note || '',
        date: b.date,
        transferFrom: b.fromBookId,
        transferTo: b.toBookId,
        fromBook: db.getBook(b.fromBookId),
        toBook: db.getBook(b.toBookId)
      })
    } else {
      this.setData({
        type: b.type,
        amount: U.fenToYuanStr(b.amount),
        activeCatId: b.categoryId,
        note: b.note || '',
        date: b.date,
        bookId: b.bookId,
        book: db.getBook(b.bookId)
      })
    }
  },

  loadCategories() {
    const type = this.data.type === 'income' ? 'income' : 'expense'
    const enabled = db.listCategories(type).filter(function (c) { return c.enabled })
    const sorted = db.sortByUsage(enabled)
    const common = sorted.slice(0, 10)
    const rest = sorted.slice(10)
    if (this.data.editingId && this.data.activeCatId) {
      // 编辑态确保当前分类可见
      const cur = db.getCategory(this.data.activeCatId)
      if (cur && common.indexOf(cur) < 0 && rest.indexOf(cur) < 0) rest.unshift(cur)
    }
    this.setData({ commonCats: common, allCats: rest })
  },

  loadBooks() {
    const books = db.listBooks()
    const curId = this.data.bookId || db.currentBookId()
    const book = db.getBook(curId)
    const fromId = this.data.transferFrom || books[0].id
    const toId = this.data.transferTo || (books[1] ? books[1].id : books[0].id)
    this.setData({
      books: books,
      book: book,
      bookId: book.id,
      fromBook: db.getBook(fromId),
      toBook: db.getBook(toId),
      transferFrom: fromId,
      transferTo: toId
    })
  },

  switchType(e) {
    const type = e.currentTarget.dataset.type
    this.setData({ type: type, activeCatId: '' })
    this.loadCategories()
  },

  selectCat(e) {
    const id = e.currentTarget.dataset.id
    this.setData({ activeCatId: this.data.activeCatId === id ? '' : id })
  },

  onKeyInput(e) {
    this.setData({ amount: e.detail.value })
  },

  onNoteInput(e) {
    this.setData({ note: e.detail.value })
  },

  quickDate(e) {
    this.setData({ date: e.currentTarget.dataset.d })
  },

  onDateChange(e) {
    this.setData({ date: e.detail.value })
  },

  pickBook() {
    const books = this.data.books
    wx.showActionSheet({
      items: books.map(function (b) { return b.icon + ' ' + b.name }),
      success: (res) => {
        const book = books[res.tapIndex]
        this.setData({ book: book, bookId: book.id })
        db.setCurrentBook(book.id)
      }
    })
  },

  pickFromBook() {
    const books = this.data.books
    wx.showActionSheet({
      items: books.map(function (b) { return b.icon + ' ' + b.name }),
      success: (res) => {
        const book = books[res.tapIndex]
        this.setData({ fromBook: book, transferFrom: book.id })
      }
    })
  },

  pickToBook() {
    const books = this.data.books
    wx.showActionSheet({
      items: books.map(function (b) { return b.icon + ' ' + b.name }),
      success: (res) => {
        const book = books[res.tapIndex]
        this.setData({ toBook: book, transferTo: book.id })
      }
    })
  },

  openCustom() {
    this.setData({ customModal: true, customName: '', customIcon: 'rice' })
  },

  closeCustom() {
    this.setData({ customModal: false })
  },

  onCustomName(e) {
    this.setData({ customName: e.detail.value })
  },

  chooseEmoji(e) {
    this.setData({ customIcon: e.currentTarget.dataset.e })
  },

  saveCustom() {
    const name = (this.data.customName || '').trim()
    if (!name) {
      wx.showToast({ title: '请输入分类名称', icon: 'none' })
      return
    }
    const type = this.data.type === 'income' ? 'income' : 'expense'
    const cat = db.addCategory(name, this.data.customIcon, type)
    this.setData({ customModal: false, activeCatId: cat.id })
    this.loadCategories()
    wx.showToast({ title: '已添加', icon: 'success' })
  },

  onKeySave() {
    this.submit()
  },

  submit() {
    const fenAmount = U.yuanToFen(this.data.amount)
    if (fenAmount <= 0) {
      wx.showToast({ title: '请输入金额', icon: 'none' })
      return
    }
    if (fenAmount > 99999999) {
      wx.showToast({ title: '金额过大', icon: 'none' })
      return
    }
    let bill = null
    if (this.data.type === 'transfer') {
      if (this.data.transferFrom === this.data.transferTo) {
        wx.showToast({ title: '请选择两个不同的账本', icon: 'none' })
        return
      }
      bill = {
        type: 'transfer',
        amount: fenAmount,
        fromBookId: this.data.transferFrom,
        toBookId: this.data.transferTo,
        bookId: this.data.transferFrom,
        categoryId: null,
        note: (this.data.note || '').slice(0, 50),
        date: this.data.date
      }
    } else {
      if (!this.data.activeCatId) {
        wx.showToast({ title: '请选择分类', icon: 'none' })
        return
      }
      bill = {
        type: this.data.type,
        amount: fenAmount,
        categoryId: this.data.activeCatId,
        bookId: this.data.bookId,
        note: (this.data.note || '').slice(0, 50),
        date: this.data.date
      }
    }

    // 超支温和提醒：确认后仍可记录
    if (this.data.type === 'expense' && !this.data.editingId) {
      const ym = U.ymOf(this.data.date)
      const budget = db.effectiveBudget(ym)
      const spent = db.monthSummary(ym).expense
      if (budget.total > 0 && spent + fenAmount > budget.total) {
        const over = spent + fenAmount - budget.total
        wx.showModal({
          title: '预算提醒',
          content: '记录后本月预算将超支 ¥' + U.fmtMoney(over) + '，确定还要记录吗？',
          confirmText: '继续记录',
          confirmColor: '#5B6CFF',
          cancelText: '再想想',
          success: (res) => {
            if (res.confirm) this.doSave(bill)
          }
        })
        return
      }
    }
    this.doSave(bill)
  },

  doSave(bill) {
    if (this.data.editingId) {
      db.updateBill(this.data.editingId, bill)
      wx.showToast({ title: '已保存', icon: 'success' })
    } else {
      db.addBill(bill)
      getApp().globalData.justSaved = true
    }
    setTimeout(() => wx.navigateBack(), 350)
  }
})
