const db = require('../../utils/store.js')
const U = require('../../utils/common.js')
const C = require('../../utils/constants.js')

Page({
  data: {
    ym: '',
    totalStr: '0.00',
    budgetTotal: 0,
    effectiveTotal: 0,
    spent: 0,
    remainStr: '0.00',
    over: false,
    carryOver: false,
    carried: 0,
    lastSurplus: 0,
    cats: [],
    ratios: C.BUDGET_RATIOS,
    totalModalVisible: false,
    totalDraft: '',
    catModalVisible: false,
    editingCat: null,
    catDraft: '',
    addCatPickerVisible: false,
    addableCats: []
  },

  onShow() {
    this.load()
  },

  load() {
    const ym = U.monthStr(new Date())
    const raw = db.getBudget(ym)
    const effective = db.effectiveBudget(ym)
    const spent = db.monthSummary(ym).expense
    const remain = effective.total - spent

    const spentMap = {}
    db.categoryTotals(ym, 'expense').forEach(function (x) { spentMap[x.id] = x.amount })

    const cats = (raw.categories || []).map(function (cb) {
      const cat = db.getCategory(cb.categoryId) || { name: '已删除分类', icon: 'plus', color: '#6E7280' }
      const s = spentMap[cb.categoryId] || 0
      return {
        id: cb.categoryId,
        name: cat.name,
        icon: cat.icon,
        color: cat.color || '#6E7280',
        limit: cb.amount,
        limitStr: U.fmtMoney(cb.amount),
        spentStr: U.fmtMoney(s),
        percent: cb.amount > 0 ? Math.min(100, Math.round((s / cb.amount) * 1000) / 10) : 0,
        over: s > cb.amount
      }
    })

    const hasBudget = {}
    ;(raw.categories || []).forEach(function (cb) { hasBudget[cb.categoryId] = true })
    const addable = db.listCategories('expense').filter(function (c) {
      return c.enabled && !hasBudget[c.id]
    })

    this.setData({
      ym: ym,
      totalStr: U.fmtMoney(raw.total),
      budgetTotal: raw.total,
      effectiveTotal: effective.total,
      spent: spent,
      remainStr: U.fmtMoney(Math.abs(remain)),
      over: remain < 0,
      carryOver: !!raw.carryOver,
      carried: effective.carried || 0,
      lastSurplus: db.lastMonthSurplus(ym),
      cats: cats,
      addableCats: addable
    })
  },

  /* ---------- 总预算 ---------- */
  openTotalModal() {
    this.setData({ totalModalVisible: true, totalDraft: U.fenToYuanStr(this.data.budgetTotal) })
  },

  closeTotalModal() {
    this.setData({ totalModalVisible: false })
  },

  onTotalDraft(e) {
    this.setData({ totalDraft: e.detail.value })
  },

  saveTotal() {
    const fen = U.yuanToFen(this.data.totalDraft)
    if (fen <= 0) {
      wx.showToast({ title: '请输入有效金额', icon: 'none' })
      return
    }
    db.saveBudget(this.data.ym, { total: fen })
    this.setData({ totalModalVisible: false })
    this.load()
    wx.showToast({ title: '已保存', icon: 'success' })
  },

  onCarryOverChange(e) {
    const val = e.detail.value
    db.saveBudget(this.data.ym, { carryOver: val })
    this.load()
    wx.showToast({ title: val ? '已开启节余结转' : '已关闭节余结转', icon: 'none' })
  },

  /* ---------- 分类预算 ---------- */
  openAddCat() {
    if (!this.data.addableCats.length) {
      wx.showToast({ title: '所有分类都已设置预算', icon: 'none' })
      return
    }
    this.setData({ addCatPickerVisible: true })
  },

  closeAddCat() {
    this.setData({ addCatPickerVisible: false })
  },

  chooseAddCat(e) {
    const id = e.currentTarget.dataset.id
    const cat = this.data.addableCats.filter(function (c) { return c.id === id })[0]
    this.setData({ addCatPickerVisible: false, catModalVisible: true, editingCat: cat, catDraft: '' })
  },

  openCatEdit(e) {
    const id = e.currentTarget.dataset.id
    const row = this.data.cats.filter(function (c) { return c.id === id })[0]
    this.setData({
      catModalVisible: true,
      editingCat: row,
      catDraft: U.fenToYuanStr(row.limit)
    })
  },

  closeCatModal() {
    this.setData({ catModalVisible: false })
  },

  onCatDraft(e) {
    this.setData({ catDraft: e.detail.value })
  },

  saveCatLimit() {
    const fen = U.yuanToFen(this.data.catDraft)
    if (fen <= 0) {
      wx.showToast({ title: '请输入有效金额', icon: 'none' })
      return
    }
    const catId = this.data.editingCat.id
    const raw = db.getBudget(this.data.ym)
    const list = (raw.categories || []).filter(function (cb) { return cb.categoryId !== catId })
    list.push({ categoryId: catId, amount: fen })
    db.saveBudget(this.data.ym, { categories: list })
    this.setData({ catModalVisible: false })
    this.load()
    wx.showToast({ title: '已保存', icon: 'success' })
  },

  removeCatLimit(e) {
    const id = e.currentTarget.dataset.id
    const raw = db.getBudget(this.data.ym)
    const list = (raw.categories || []).filter(function (cb) { return cb.categoryId !== id })
    db.saveBudget(this.data.ym, { categories: list })
    this.load()
  },

  /* ---------- 按比例推荐 ---------- */
  applyRecommend() {
    const total = this.data.budgetTotal
    if (total <= 0) {
      wx.showToast({ title: '请先设置总预算', icon: 'none' })
      return
    }
    const enabled = db.listCategories('expense').filter(function (c) { return c.enabled })
    const list = []
    C.BUDGET_RATIOS.forEach(function (r) {
      const cat = enabled.filter(function (c) { return c.name === r.name })[0]
      if (cat) list.push({ categoryId: cat.id, amount: Math.round((total * r.ratio) / 100) })
    })
    db.saveBudget(this.data.ym, { categories: list })
    this.load()
    wx.showToast({ title: '已按推荐比例分配', icon: 'success' })
  }
})
