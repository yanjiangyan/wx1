const db = require('../../utils/store.js')
const U = require('../../utils/common.js')

Page({
  data: {
    bill: {},
    catName: '',
    icon: '📌',
    bookName: '',
    fromName: '',
    toName: '',
    amountStr: '0.00',
    typeLabel: '支出',
    dateCN: '',
    weekday: '',
    time: ''
  },

  onLoad(options) {
    const id = options.id
    const b = db.getBill(id)
    if (!b) {
      wx.showToast({ title: '账单不存在', icon: 'none' })
      setTimeout(() => wx.navigateBack(), 600)
      return
    }
    const cat = b.categoryId ? db.getCategory(b.categoryId) : null
    const book = db.getBook(b.bookId)
    this.setData({
      bill: b,
      catName: cat ? cat.name : '转账',
      icon: cat ? cat.icon : '🔁',
      bookName: book ? book.name : '',
      fromName: b.fromBookId ? (db.getBook(b.fromBookId) || {}).name : '',
      toName: b.toBookId ? (db.getBook(b.toBookId) || {}).name : '',
      amountStr: U.fmtMoney(b.amount),
      typeLabel: b.type === 'expense' ? '支出' : b.type === 'income' ? '收入' : '转账',
      dateCN: U.fmtDateCN(b.date),
      weekday: U.weekdayCN(b.date),
      time: U.timeOf(b.createdAt || Date.now())
    })
    wx.setNavigationBarTitle({ title: '账单详情' })
  },

  onEdit() {
    wx.navigateTo({ url: '/pages/record/record?id=' + this.data.bill.id })
  },

  onDelete() {
    wx.showModal({
      title: '删除账单',
      content: '确定删除这笔账单吗？删除后不可恢复。',
      confirmText: '删除',
      confirmColor: '#F5483B',
      success: (res) => {
        if (res.confirm) {
          db.deleteBill(this.data.bill.id)
          wx.showToast({ title: '已删除', icon: 'success' })
          setTimeout(() => wx.navigateBack(), 500)
        }
      }
    })
  }
})
