# -*- coding: utf-8 -*-
"""生成 tabBar 图标（81x81 PNG，4 倍超采样抗锯齿）。

深色暗黑主题规范：
- 未选中：灰色 #6E7280 线性图标（outline）
- 选中  ：品牌蓝 #2B7CFF 面性图标（filled）

用法：
    python tools/gen_icons.py
输出：
    images/tab/{book,asset,piggy,chart}{,-active}.png
"""
import os
from PIL import Image, ImageDraw

SIZE = 81
SS = 4  # 超采样倍数
OUT = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "images", "tab")

ACTIVE = (43, 124, 255, 255)    # #2B7CFF 品牌主色（面性）
INACTIVE = (110, 114, 128, 255)  # #6E7280 三级灰（线性）
W = 5  # 线宽（视觉 2px @4x 超采样）


def canvas():
    img = Image.new("RGBA", (SIZE * SS, SIZE * SS), (0, 0, 0, 0))
    return img, ImageDraw.Draw(img)


def s(v):
    return v * SS


def draw_book(d, color, filled):
    # 账本：圆角矩形 + 书脊竖线
    d.rounded_rectangle([s(16), s(12), s(65), s(69)], radius=s(7),
                        fill=color if filled else None, outline=color, width=s(W if not filled else 1))
    # 书脊
    d.line([s(40), s(12), s(40), s(69)], fill=(0, 0, 0, 0) if filled else color,
           width=s(2 if filled else W - 1))


def draw_asset(d, color, filled):
    # 资产：盾形 + 对勾
    shield = [(s(40), s(10)), (s(66), s(19)), (s(66), s(40)),
              (s(40), s(71)), (s(14), s(40)), (s(14), s(19))]
    d.polygon(shield, fill=color if filled else None, outline=color, width=s(W if not filled else 1))
    if filled:
        # 对勾用透明"挖空"
        check = [(s(28), s(38)), (s(36), s(47)), (s(54), s(27)), (s(48), s(22)),
                 (s(36), s(39)), (s(31), s(34))]
        d.line(check, fill=(0, 0, 0, 0), width=s(7), joint="curve")
    else:
        d.line([(s(27), s(38)), (s(37), s(48)), (s(54), s(27))], fill=color, width=s(W - 1), joint="curve")


def draw_piggy(d, color, filled):
    # 存钱：小猪（身体 + 鼻子 + 耳朵 + 腿）
    d.ellipse([s(12), s(24), s(60), s(62)], fill=color if filled else None,
              outline=color, width=s(W if not filled else 1))
    # 鼻子
    d.ellipse([s(55), s(34), s(72), s(50)], fill=color if filled else None,
              outline=color, width=s(W if not filled else 1))
    # 鼻孔
    d.ellipse([s(60), s(40), s(65), s(45)], fill=(0, 0, 0, 0) if filled else color)
    # 耳朵
    d.polygon([(s(20), s(26)), (s(24), s(14)), (s(30), s(24))], fill=color if filled else None,
              outline=color, width=s(W - 1 if not filled else 1))
    # 腿
    d.rounded_rectangle([s(18), s(56), s(27), s(70)], radius=s(4),
                        fill=color if filled else None, outline=color, width=s(W if not filled else 1))
    d.rounded_rectangle([s(45), s(56), s(54), s(70)], radius=s(4),
                        fill=color if filled else None, outline=color, width=s(W if not filled else 1))


def draw_chart(d, color, filled):
    # 统计：三根圆角柱
    d.rounded_rectangle([s(14), s(44), s(27), s(68)], radius=s(4), fill=color if filled else None,
                        outline=color, width=s(W if not filled else 1))
    d.rounded_rectangle([s(36), s(28), s(49), s(68)], radius=s(4), fill=color if filled else None,
                        outline=color, width=s(W if not filled else 1))
    d.rounded_rectangle([s(58), s(15), s(71), s(68)], radius=s(4), fill=color if filled else None,
                        outline=color, width=s(W if not filled else 1))


DRAWERS = {
    "book": draw_book,
    "asset": draw_asset,
    "piggy": draw_piggy,
    "chart": draw_chart,
}


def render(name, color, filled):
    img, d = canvas()
    DRAWERS[name](d, color, filled)
    return img.resize((SIZE, SIZE), Image.LANCZOS)


def main():
    os.makedirs(OUT, exist_ok=True)
    # 清理旧主题图标
    for old in ("home", "bill", "me"):
        for suffix in (".png", "-active.png"):
            p = os.path.join(OUT, old + suffix)
            if os.path.exists(p):
                os.remove(p)
    for name in DRAWERS:
        render(name, INACTIVE, False).save(os.path.join(OUT, name + ".png"))
        render(name, ACTIVE, True).save(os.path.join(OUT, name + "-active.png"))
        print("generated", name)


if __name__ == "__main__":
    main()
