#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""campus-ledger 交付前校验：JS 语法 / JSON 合法性 / 交叉引用 / 图标引用。"""
import json
import os
import re
import subprocess
import sys

NODE = r"C:/Users/WINDOWS/.workbuddy/binaries/node/versions/22.22.2-6/node.exe"
ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))

errors = []


def rel(p):
    return os.path.relpath(p, ROOT).replace("\\", "/")


# 1. JS 语法检查
js_files = []
for dirpath, _, files in os.walk(ROOT):
    if "node_modules" in dirpath:
        continue
    for f in files:
        if f.endswith(".js"):
            js_files.append(os.path.join(dirpath, f))
for f in js_files:
    r = subprocess.run([NODE, "--check", f], capture_output=True, text=True)
    if r.returncode != 0:
        errors.append("JS 语法错误 %s:\n%s" % (rel(f), r.stderr[:400]))

# 2. JSON 合法性
json_files = []
for dirpath, _, files in os.walk(ROOT):
    if "node_modules" in dirpath:
        continue
    for f in files:
        if f.endswith(".json"):
            json_files.append(os.path.join(dirpath, f))
for f in json_files:
    try:
        with open(f, encoding="utf-8") as fp:
            json.load(fp)
    except Exception as e:
        errors.append("JSON 错误 %s: %s" % (rel(f), e))

# 3. app.json 页面与 tabBar 图标存在性
app = json.load(open(os.path.join(ROOT, "app.json"), encoding="utf-8"))
for p in app["pages"]:
    for ext in (".js", ".json", ".wxml", ".wxss"):
        fp = os.path.join(ROOT, p + ext)
        if not os.path.exists(fp):
            errors.append("缺少页面文件: %s%s" % (p, ext))
for item in app["tabBar"]["list"]:
    for k in ("iconPath", "selectedIconPath"):
        if not os.path.exists(os.path.join(ROOT, item[k])):
            errors.append("缺少 tab 图标: %s" % item[k])

# 4. usingComponents 路径存在
for dirpath, _, files in os.walk(ROOT):
    if "node_modules" in dirpath:
        continue
    for f in files:
        if not f.endswith(".json"):
            continue
        cfg_path = os.path.join(dirpath, f)
        try:
            data = json.load(open(cfg_path, encoding="utf-8"))
        except Exception:
            continue
        for name, path in (data.get("usingComponents") or {}).items():
            p = path.lstrip("/")
            if not os.path.exists(os.path.join(ROOT, p + ".js")):
                errors.append("%s -> 组件缺失: %s" % (rel(cfg_path), path))

# 5. WXML 事件处理器必须在 JS 中定义
for dirpath, _, files in os.walk(ROOT):
    if "node_modules" in dirpath:
        continue
    for f in files:
        if not f.endswith(".wxml"):
            continue
        wxml = os.path.join(dirpath, f)
        js = wxml[:-5] + ".js"
        if not os.path.exists(js):
            continue
        content = open(wxml, encoding="utf-8").read()
        handlers = set(re.findall(r'(?:bind:|catch:|bind)[a-zA-Z:]*=\s*"([a-zA-Z_][a-zA-Z0-9_]*)"', content))
        src = open(js, encoding="utf-8").read()
        for h in sorted(handlers):
            if not re.search(r"\b" + re.escape(h) + r"\s*[(:]", src):
                errors.append("%s -> 事件未定义: %s" % (rel(wxml), h))

# 6. line-icon 名称引用校验（constants 的 icon / CUSTOM_ICONS / wxml 静态名）
icon_js = open(os.path.join(ROOT, "components/line-icon/line-icon.js"), encoding="utf-8").read()
icon_names = set(re.findall(r"^\s{2}(\w+):\s*\[", icon_js, re.M))
constants = open(os.path.join(ROOT, "utils/constants.js"), encoding="utf-8").read()
for name in re.findall(r"icon:\s*'(\w+)'", constants):
    if name not in icon_names:
        errors.append("constants 引用了不存在的图标: %s" % name)
custom = re.search(r"var CUSTOM_ICONS = \[([^\]]+)\]", constants)
if custom:
    for name in re.findall(r"'(\w+)'", custom.group(1)):
        if name not in icon_names:
            errors.append("CUSTOM_ICONS 引用了不存在的图标: %s" % name)
# wxml 中静态 name="xxx" 引用
for dirpath, _, files in os.walk(ROOT):
    if "node_modules" in dirpath:
        continue
    for f in files:
        if not f.endswith(".wxml"):
            continue
        wxml = os.path.join(dirpath, f)
        content = open(wxml, encoding="utf-8").read()
        for name in re.findall(r'name="(\w+)"', content):
            if name not in icon_names and name not in ("pieCanvas", "lineCanvas", "cmpCanvas"):
                errors.append("%s -> line-icon 名称不存在: %s" % (rel(wxml), name))

print("JS 文件: %d，JSON 文件: %d，line-icon 图标: %d" % (len(js_files), len(json_files), len(icon_names)))
if errors:
    print("=== 校验发现问题 ===")
    for e in errors:
        print(" -", e)
    sys.exit(1)
print("=== 全部校验通过 ===")
