/*
 * 数据层冒烟测试（Node 环境运行，mock wx 存储 API）
 * 用法：node tools/smoke_test.js
 * 覆盖：种子数据、记账、预算（含结转）、待办、储蓄目标、兼职、AA、统计、演示数据、清空。
 */
const assert = require('assert')

// ---- mock wx ----
const storage = {}
global.wx = {
  getStorageSync: (k) => storage[k],
  setStorageSync: (k, v) => { storage[k] = v },
  removeStorageSync: (k) => { delete storage[k] },
  getSystemInfoSync: () => ({ pixelRatio: 2 })
}
// ---- mock 小程序构造器（供 line-icon 组件在 Node 下加载）----
global.Component = () => {}
global.Page = () => {}

const db = require('../utils/store.js')
const U = require('../utils/common.js')
const C = require('../utils/constants.js')
const lineIcon = require('../components/line-icon/line-icon.js')

let passed = 0
function ok(name, fn) {
  fn()
  passed += 1
  console.log('  ✓ ' + name)
}

console.log('[smoke] 数据层冒烟测试')

ok('init 写入种子数据（无引导，直接使用预设）', () => {
  db.init()
  assert.strictEqual(db.getProfile().monthlyAllowance, 150000)
  assert.strictEqual(db.getProfile().nickname, '同学')
  assert.strictEqual(db.listBooks().length, 1)
  assert.ok(db.listCategories('expense').length >= 20)
  assert.ok(db.listCategories('income').length >= 5)
  // 无新手引导：默认预算直接取月生活费
  const ym = U.monthStr(new Date())
  assert.strictEqual(db.getBudget(ym).total, 150000)
})

ok('分类结构：线形图标名 + 圆形底色', () => {
  const all = db.listCategories('expense').concat(db.listCategories('income'))
  all.forEach((c) => {
    assert.ok(lineIcon.ICONS[c.icon], '图标不存在: ' + c.icon)
    assert.ok(/^#[0-9A-Fa-f]{6}$/.test(c.color || ''), '分类底色缺失: ' + c.name)
  })
  C.CUSTOM_ICONS.forEach((n) => assert.ok(lineIcon.ICONS[n], 'CUSTOM_ICONS 图标不存在: ' + n))
})

ok('自定义分类：图标与色底自动分配', () => {
  const cat = db.addCategory('测试分类', 'rice', 'expense')
  assert.strictEqual(cat.icon, 'rice')
  assert.ok(/^#[0-9A-Fa-f]{6}$/.test(cat.color))
  const inc = db.addCategory('测试收入', 'plus', 'income')
  assert.strictEqual(inc.color, '#2ECC71')
})

ok('按日收入聚合与分类笔数', () => {
  const today = U.dateStr(new Date())
  const ym = U.monthStr(new Date())
  const inc = db.listCategories('income').filter((c) => c.name === '生活费')[0]
  db.addBill({ type: 'income', amount: 5000, categoryId: inc.id, bookId: 'book_life', note: '红包', date: today })
  const exp = db.listCategories('expense').filter((c) => c.name === '食堂')[0]
  db.addBill({ type: 'expense', amount: 1200, categoryId: exp.id, bookId: 'book_life', note: '早饭', date: today })
  const incMap = db.dailyIncomeMap(ym)
  assert.ok(incMap[today] >= 5000)
  const counts = db.categoryCounts(ym, 'expense')
  assert.ok(counts[exp.id] >= 1)
})

ok('记账：支出/收入/转账', () => {
  const today = U.dateStr(new Date())
  const cat = db.listCategories('expense').filter((c) => c.name === '食堂')[0]
  db.addBill({ type: 'expense', amount: 1500, categoryId: cat.id, bookId: 'book_life', note: '午饭', date: today })
  db.addBill({ type: 'income', amount: 150000, categoryId: db.listCategories('income')[0].id, bookId: 'book_life', note: '生活费', date: today })
  const s = db.monthSummary(U.monthStr(new Date()))
  // 含前置测试预记的 1200 支出 / 5000 收入
  assert.strictEqual(s.expense, 2700)
  assert.strictEqual(s.income, 155000)
  assert.strictEqual(s.balance, 152300)
  const totals = db.categoryTotals(U.monthStr(new Date()), 'expense')
  assert.ok(totals.length >= 1 && totals[0].amount === 2700)
  // 常用分类使用频次递增
  assert.ok(db.getCategory(cat.id).usage === 2)
})

ok('账单筛选：日期/分类/金额区间/关键词', () => {
  const today = U.dateStr(new Date())
  assert.strictEqual(db.listBills({ date: today }).length, 4)
  assert.strictEqual(db.listBills({ keyword: '午饭' }).length, 1)
  assert.strictEqual(db.listBills({ min: 100000 }).length, 1)
  assert.strictEqual(db.listBills({ max: 2000 }).length, 2)
  assert.strictEqual(db.listBills({ month: '1999-01' }).length, 0)
})

ok('预算：总预算与生效预算', () => {
  const ym = U.monthStr(new Date())
  db.saveBudget(ym, { total: 200000 })
  assert.strictEqual(db.getBudget(ym).total, 200000)
  assert.strictEqual(db.effectiveBudget(ym).total, 200000)
})

ok('预算：节余结转', () => {
  const ym = U.monthStr(new Date())
  const prevYm = U.addMonths(ym, -1)
  db.saveBudget(prevYm, { total: 100000, carryOver: true })
  // 向上月记一笔 10 元支出，结余 99000 结转至本月
  const cat = db.listCategories('expense').filter((c) => c.name === '食堂')[0]
  db.addBill({ type: 'expense', amount: 1000, categoryId: cat.id, bookId: 'book_life', note: '上月账单', date: prevYm + '-15' })
  db.saveBudget(ym, { carryOver: true })
  const eff = db.effectiveBudget(ym)
  assert.strictEqual(eff.carried, 99000)
  assert.strictEqual(eff.total, 299000)
})

ok('待办：增删、完成、排序', () => {
  const t1 = db.addTodo('写作业', 'high', U.dateStr(new Date()))
  const t2 = db.addTodo('去跑步', 'low', '')
  assert.strictEqual(db.listTodos().length, 2)
  db.toggleTodo(t1.id)
  assert.strictEqual(db.getTodo(t1.id).done, true)
  db.moveTodo(t2.id, -1)
  assert.strictEqual(db.listTodos()[0].id, t2.id)
  db.deleteTodo(t1.id)
  assert.strictEqual(db.listTodos().length, 1)
})

ok('储蓄目标：创建、存入、划拨', () => {
  const g = db.addGoal('买电脑', 500000, 50000, '💻')
  db.depositGoal(g.id, 120000)
  assert.strictEqual(db.listGoals()[0].saved, 120000)
  db.depositGoal(g.id, 50000)
  assert.strictEqual(db.listGoals()[0].saved, 170000)
  // 超出目标时封顶
  db.depositGoal(g.id, 999999)
  assert.strictEqual(db.listGoals()[0].saved, 500000)
})

ok('兼职收入记录', () => {
  db.addPartTime(30000, '家教', U.dateStr(new Date()), '数学 2 小时')
  assert.strictEqual(db.listPartTime().length, 1)
  db.deletePartTime(db.listPartTime()[0].id)
  assert.strictEqual(db.listPartTime().length, 0)
})

ok('AA 分账：人均与尾差计算', () => {
  const total = 10000 // 100 元
  const people = 3
  const per = Math.floor(total / people) // 3333
  const remainder = total - per * people // 1
  assert.strictEqual(per, 3333)
  assert.strictEqual(remainder, 1)
  db.addAA(total, people, per, U.dateStr(new Date()))
  assert.strictEqual(db.listAA().length, 1)
})

ok('统计：趋势与周对比', () => {
  const trend = db.trendExpense(6)
  assert.strictEqual(trend.length, 6)
  const wc = db.weekCompare()
  assert.ok(wc.cur >= 0 && wc.prev >= 0)
  const top3 = db.weekTopCategories()
  assert.ok(top3.length <= 3)
  assert.ok(db.totalStat().billCount >= 3)
})

ok('账本：新增、切换、删除（账单转移）', () => {
  const b = db.addBook('奖学金', '🏆')
  assert.strictEqual(db.listBooks().length, 2)
  db.setCurrentBook(b.id)
  assert.strictEqual(db.currentBookId(), b.id)
  const r = db.deleteBook(b.id)
  assert.strictEqual(r.ok, true)
  assert.strictEqual(db.listBooks().length, 1)
  // 删除后账单全部落在默认账本
  db.listBills().forEach((x) => assert.ok(x.bookId === 'book_life'))
})

ok('演示数据与清空', () => {
  db.seedDemoData()
  assert.ok(db.listBills().length > 30)
  assert.ok(db.listTodos().length >= 1)
  db.clearAll()
  assert.strictEqual(db.listBills().length, 0)
  assert.strictEqual(db.listCategories('expense').length >= 20, true)
})

console.log('[smoke] 全部通过：' + passed + ' 组断言')
