const db = require('./utils/store.js')

App({
  onLaunch() {
    // 初始化本地仓储（首次启动写入预置分类、默认账本等种子数据）
    db.init()
  },
  globalData: {
    justSaved: false // 记账保存后用于触发首页数字更新动画
  }
})
