/*
 * Canvas 2D 图表工具（微信小程序原生 canvas，无需第三方图表库）
 * 深色暗黑主题：深色网格、规范色板、白/#B0B3C0 文字，统一处理 DPR 适配。
 */
const C = require('./constants.js')

const TEXT_MAIN = '#FFFFFF'   // 一级文字
const TEXT_SUB = '#B0B3C0'    // 二级文字
const TEXT_WEAK = '#6E7280'   // 三级文字
const GRID = 'rgba(255, 255, 255, 0.08)'
const TRACK = 'rgba(255, 255, 255, 0.08)'
const BRAND = '#2B7CFF'       // 品牌主色

function prep(canvas, ctx, w, h) {
  const dpr = wx.getSystemInfoSync().pixelRatio || 2
  canvas.width = w * dpr
  canvas.height = h * dpr
  ctx.scale(dpr, dpr)
  ctx.clearRect(0, 0, w, h)
  ctx.textBaseline = 'middle'
}

function drawEmpty(ctx, w, h, text) {
  ctx.fillStyle = TEXT_WEAK
  ctx.font = '13px sans-serif'
  ctx.textAlign = 'center'
  ctx.fillText(text || '暂无数据', w / 2, h / 2)
}

/* 环形饼图 + 图例（items: [{name, amount}]） */
function drawPie(canvas, ctx, w, h, items) {
  prep(canvas, ctx, w, h)
  const total = items.reduce(function (s, x) { return s + x.amount }, 0)
  if (!total) { drawEmpty(ctx, w, h, '本月暂无支出'); return }

  // 超过 8 项合并为「其他」
  let data = items.slice(0, 8)
  if (items.length > 8) {
    const rest = items.slice(8).reduce(function (s, x) { return s + x.amount }, 0)
    data.push({ name: '其他', amount: rest })
  }

  const cx = w * 0.3
  const cy = h / 2
  const r = Math.min(w * 0.32, h / 2 - 14)
  const ir = r * 0.62
  let start = -Math.PI / 2
  data.forEach(function (it, i) {
    const ang = (it.amount / total) * Math.PI * 2
    ctx.beginPath()
    ctx.arc(cx, cy, r, start, start + ang)
    ctx.arc(cx, cy, ir, start + ang, start, true)
    ctx.closePath()
    ctx.fillStyle = C.CHART_COLORS[i % C.CHART_COLORS.length]
    ctx.fill()
    start += ang
  })

  // 中心文字（规范：居中展示总支出金额）
  ctx.fillStyle = TEXT_SUB
  ctx.textAlign = 'center'
  ctx.font = '12px sans-serif'
  ctx.fillText('本月支出', cx, cy - 12)
  ctx.font = 'bold 18px sans-serif'
  ctx.fillStyle = TEXT_MAIN
  ctx.fillText('¥' + (total / 100).toFixed(0), cx, cy + 12)

  // 图例（外侧标注占比百分比）
  const lx = cx + r + 26
  const lineH = Math.min(24, (h - 20) / data.length)
  let ly = cy - ((data.length - 1) * lineH) / 2
  ctx.textAlign = 'left'
  data.forEach(function (it, i) {
    ctx.fillStyle = C.CHART_COLORS[i % C.CHART_COLORS.length]
    ctx.fillRect(lx, ly - 5, 10, 10)
    ctx.fillStyle = TEXT_SUB
    ctx.font = '12px sans-serif'
    const pct = ((it.amount / total) * 100).toFixed(1)
    ctx.fillText(it.name + ' ' + pct + '%', lx + 16, ly)
    ly += lineH
  })
}

/* 折线图（近 6 个月支出趋势，深色网格 + 峰值标注） */
function drawLine(canvas, ctx, w, h, points) {
  prep(canvas, ctx, w, h)
  if (!points.length || points.every(function (p) { return !p.expense })) {
    drawEmpty(ctx, w, h, '暂无趋势数据')
    return
  }
  const padL = 46
  const padR = 20
  const padT = 24
  const padB = 34
  const cw = w - padL - padR
  const ch = h - padT - padB
  const max = Math.max.apply(null, points.map(function (p) { return p.expense })) * 1.15 || 1

  // 网格线与刻度
  ctx.strokeStyle = GRID
  ctx.lineWidth = 1
  ctx.fillStyle = TEXT_WEAK
  ctx.font = '11px sans-serif'
  ctx.textAlign = 'right'
  for (let i = 0; i <= 3; i++) {
    const y = padT + (ch / 3) * i
    ctx.beginPath()
    ctx.moveTo(padL, y)
    ctx.lineTo(w - padR, y)
    ctx.stroke()
    ctx.fillText('¥' + Math.round((max / 3) * (3 - i) / 100), padL - 6, y)
  }

  const px = function (i) { return padL + (cw / (points.length - 1)) * i }
  const py = function (v) { return padT + ch - (v / max) * ch }

  // 峰值索引（规范：标注峰值金额与对应日期）
  let peakIdx = 0
  points.forEach(function (p, i) {
    if (p.expense > points[peakIdx].expense) peakIdx = i
  })

  // 渐变面积
  const grad = ctx.createLinearGradient(0, padT, 0, padT + ch)
  grad.addColorStop(0, 'rgba(43,124,255,0.28)')
  grad.addColorStop(1, 'rgba(43,124,255,0.02)')
  ctx.beginPath()
  ctx.moveTo(px(0), py(points[0].expense))
  points.forEach(function (p, i) { ctx.lineTo(px(i), py(p.expense)) })
  ctx.lineTo(px(points.length - 1), padT + ch)
  ctx.lineTo(px(0), padT + ch)
  ctx.closePath()
  ctx.fillStyle = grad
  ctx.fill()

  // 折线
  ctx.beginPath()
  ctx.moveTo(px(0), py(points[0].expense))
  points.forEach(function (p, i) { ctx.lineTo(px(i), py(p.expense)) })
  ctx.strokeStyle = BRAND
  ctx.lineWidth = 2.5
  ctx.stroke()

  // 数据点与标签
  ctx.textAlign = 'center'
  points.forEach(function (p, i) {
    const isPeak = i === peakIdx && p.expense > 0
    if (isPeak) {
      // 峰值外圈高亮
      ctx.beginPath()
      ctx.arc(px(i), py(p.expense), 8, 0, Math.PI * 2)
      ctx.fillStyle = 'rgba(43, 124, 255, 0.25)'
      ctx.fill()
    }
    ctx.beginPath()
    ctx.arc(px(i), py(p.expense), 4, 0, Math.PI * 2)
    ctx.fillStyle = '#16171D'
    ctx.fill()
    ctx.strokeStyle = BRAND
    ctx.lineWidth = 2
    ctx.stroke()
    ctx.fillStyle = TEXT_WEAK
    ctx.font = '11px sans-serif'
    ctx.fillText(p.ym.slice(5) + '月', px(i), h - 16)
    ctx.fillStyle = isPeak ? BRAND : TEXT_SUB
    ctx.font = isPeak ? 'bold 11px sans-serif' : '11px sans-serif'
    ctx.fillText('¥' + Math.round(p.expense / 100), px(i), py(p.expense) - 14)
  })
}

/* 分类 TOP5 横向条形图（items: [{name, amount}]） */
function drawTopBars(canvas, ctx, w, h, items) {
  prep(canvas, ctx, w, h)
  if (!items.length) { drawEmpty(ctx, w, h, '暂无排行数据'); return }
  const unit = w / 750 // rpx -> px
  const labelW = 150 * unit
  const valueW = 130 * unit
  const barMax = w - labelW - valueW - 20
  const max = items[0].amount || 1
  const rowH = h / items.length

  items.forEach(function (it, i) {
    const cy = rowH * i + rowH / 2
    const barH = Math.min(22 * unit, rowH * 0.5)
    const bw = Math.max(4, (it.amount / max) * barMax)
    ctx.fillStyle = TEXT_SUB
    ctx.font = '12px sans-serif'
    ctx.textAlign = 'left'
    ctx.fillText(it.name.length > 5 ? it.name.slice(0, 5) : it.name, 0, cy)
    // 底槽
    ctx.fillStyle = TRACK
    roundRect(ctx, labelW, cy - barH / 2, barMax, barH, barH / 2)
    ctx.fill()
    // 数据条
    ctx.fillStyle = C.CHART_COLORS[i % C.CHART_COLORS.length]
    roundRect(ctx, labelW, cy - barH / 2, bw, barH, barH / 2)
    ctx.fill()
    // 金额
    ctx.fillStyle = TEXT_MAIN
    ctx.font = 'bold 12px sans-serif'
    ctx.textAlign = 'right'
    ctx.fillText('¥' + (it.amount / 100).toFixed(0), w, cy)
  })
}

/* 日均消费对比（本月 vs 上月，双柱状图） */
function drawCompare(canvas, ctx, w, h, cur, prev) {
  prep(canvas, ctx, w, h)
  const max = Math.max(cur, prev, 1)
  const barW = Math.min(90, w * 0.2)
  const gap = w * 0.14
  const baseY = h - 40
  const topY = 26
  const usable = baseY - topY
  const cx1 = w / 2 - gap / 2 - barW / 2
  const cx2 = w / 2 + gap / 2 + barW / 2

  // 本月
  const h1 = Math.max(4, (cur / max) * usable)
  ctx.fillStyle = BRAND
  roundRect(ctx, cx1, baseY - h1, barW, h1, 10)
  ctx.fill()
  ctx.fillStyle = TEXT_MAIN
  ctx.font = 'bold 13px sans-serif'
  ctx.textAlign = 'center'
  ctx.fillText('¥' + (cur / 100).toFixed(1), cx1 + barW / 2, baseY - h1 - 12)
  ctx.fillStyle = TEXT_WEAK
  ctx.font = '12px sans-serif'
  ctx.fillText('本月日均', cx1 + barW / 2, h - 16)

  // 上月
  const h2 = Math.max(4, (prev / max) * usable)
  ctx.fillStyle = 'rgba(255, 255, 255, 0.15)'
  roundRect(ctx, cx2, baseY - h2, barW, h2, 10)
  ctx.fill()
  ctx.fillStyle = TEXT_MAIN
  ctx.font = 'bold 13px sans-serif'
  ctx.fillText('¥' + (prev / 100).toFixed(1), cx2 + barW / 2, baseY - h2 - 12)
  ctx.fillStyle = TEXT_WEAK
  ctx.font = '12px sans-serif'
  ctx.fillText('上月日均', cx2 + barW / 2, h - 16)

  // 基准线
  ctx.strokeStyle = GRID
  ctx.lineWidth = 1
  ctx.beginPath()
  ctx.moveTo(10, baseY)
  ctx.lineTo(w - 10, baseY)
  ctx.stroke()
}

function roundRect(ctx, x, y, w, h, r) {
  r = Math.min(r, w / 2, h / 2)
  ctx.beginPath()
  ctx.moveTo(x + r, y)
  ctx.arcTo(x + w, y, x + w, y + h, r)
  ctx.arcTo(x + w, y + h, x, y, h)
  ctx.arcTo(x, y + h, x, y, r)
  ctx.arcTo(x, y, x + w, y, r)
  ctx.closePath()
}

module.exports = { drawPie, drawLine, drawTopBars, drawCompare }
