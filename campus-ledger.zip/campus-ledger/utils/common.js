/* 通用工具：日期与金额处理（金额一律以「分」为单位存储，避免浮点误差） */

function pad2(n) {
  return n < 10 ? '0' + n : String(n)
}

function dateStr(d) {
  d = d || new Date()
  return d.getFullYear() + '-' + pad2(d.getMonth() + 1) + '-' + pad2(d.getDate())
}

function monthStr(d) {
  d = d || new Date()
  return d.getFullYear() + '-' + pad2(d.getMonth() + 1)
}

function ymOf(s) {
  return String(s || dateStr()).slice(0, 7)
}

function parseDate(s) {
  const p = String(s).split('-')
  return new Date(+p[0], +p[1] - 1, +p[2])
}

function addDays(s, n) {
  const d = parseDate(s)
  d.setDate(d.getDate() + n)
  return dateStr(d)
}

function addMonths(ym, n) {
  const p = ym.split('-')
  const d = new Date(+p[0], +p[1] - 1 + n, 1)
  return monthStr(d)
}

function daysInMonth(ym) {
  const p = ym.split('-')
  return new Date(+p[0], +p[1], 0).getDate()
}

function weekdayCN(s) {
  return '周' + '日一二三四五六'.charAt(parseDate(s).getDay())
}

// 分 -> "12.34"
function fmtMoney(cents) {
  const neg = cents < 0
  const v = Math.abs(cents) / 100
  return (neg ? '-' : '') + v.toFixed(2)
}

// "12.3" / "12" -> 1230 分
function yuanToFen(s) {
  s = String(s == null ? '' : s).trim()
  if (!s) return 0
  const n = Number(s)
  if (isNaN(n)) return 0
  return Math.round(n * 100)
}

function fenToYuanStr(cents) {
  return (Math.abs(cents) / 100).toFixed(2)
}

// 2026-10-13 -> 10月13日
function fmtDateCN(s) {
  const d = parseDate(s)
  return (d.getMonth() + 1) + '月' + d.getDate() + '日'
}

function greeting() {
  const h = new Date().getHours()
  if (h < 6) return '夜深了'
  if (h < 9) return '早上好'
  if (h < 12) return '上午好'
  if (h < 14) return '中午好'
  if (h < 18) return '下午好'
  return '晚上好'
}

function timeOf(ts) {
  const d = new Date(ts)
  return pad2(d.getHours()) + ':' + pad2(d.getMinutes())
}

function uid() {
  return Date.now().toString(36) + Math.random().toString(36).slice(2, 8)
}

module.exports = {
  pad2,
  dateStr,
  monthStr,
  ymOf,
  parseDate,
  addDays,
  addMonths,
  daysInMonth,
  weekdayCN,
  fmtMoney,
  yuanToFen,
  fenToYuanStr,
  fmtDateCN,
  greeting,
  timeOf,
  uid
}
