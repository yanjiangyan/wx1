/*
 * 数据仓储层（Repository）
 * 统一封装 wx.Storage 读写，向上提供用户 / 账本 / 分类 / 账单 / 预算 /
 * 待办 / 储蓄目标 / 兼职 / AA 分账的访问 API。
 * 后续接入云后端时，仅需替换本文件内部实现，页面层无感知。
 */
const C = require('./constants.js')
const U = require('./common.js')

const PREFIX = 'sk_'
const K = {
  meta: 'meta',
  profile: 'profile',
  books: 'books',
  categories: 'categories',
  bills: 'bills',
  budgets: 'budgets',
  todos: 'todos',
  goals: 'goals',
  parttime: 'parttime',
  aa: 'aa'
}

function read(key, fallback) {
  try {
    const v = wx.getStorageSync(PREFIX + key)
    if (v === '' || v === undefined || v === null) return fallback
    return v
  } catch (e) {
    return fallback
  }
}

function write(key, val) {
  try {
    wx.setStorageSync(PREFIX + key, val)
    return true
  } catch (e) {
    return false
  }
}

/* ---------- 种子数据 ---------- */
// 老数据迁移：为缺少 color 字段的分类补上规范圆形底色
function ensureCategoryColors() {
  const list = read(K.categories, [])
  let changed = false
  const preset = {}
  C.PRESET_EXPENSE.forEach(function (g) {
    g.items.forEach(function (it) { preset[it.name] = it.color })
  })
  C.PRESET_INCOME.forEach(function (it) { preset[it.name] = it.color })
  const palette = ['#FF6B6B', '#FF9F43', '#FFD166', '#2ECC71', '#4ECDC4', '#2B7CFF', '#A78BFA', '#F472B6']
  list.forEach(function (c, idx) {
    if (!c.color) {
      c.color = preset[c.name] || palette[idx % palette.length]
      changed = true
    }
  })
  if (changed) write(K.categories, list)
}

function seedCategories() {
  const list = []
  let i = 0
  C.PRESET_EXPENSE.forEach(function (g) {
    g.items.forEach(function (it) {
      i += 1
      list.push({
        id: 'c' + i, name: it.name, icon: it.icon, color: it.color, type: 'expense',
        group: g.group, usage: 0, enabled: true, custom: false
      })
    })
  })
  C.PRESET_INCOME.forEach(function (it) {
    i += 1
    list.push({
      id: 'c' + i, name: it.name, icon: it.icon, color: it.color, type: 'income',
      group: '收入', usage: 0, enabled: true, custom: false
    })
  })
  return list
}

function init() {
  if (read(K.meta, null) === null) {
    write(K.meta, { version: 1, createdAt: Date.now() })
  }
  if (read(K.profile, null) === null) {
    write(K.profile, {
      nickname: '同学', avatar: '🐯', monthlyAllowance: 150000,
      createdAt: Date.now()
    })
  }
  if (read(K.books, null) === null) {
    write(K.books, [{
      id: 'book_life', name: '生活费', icon: '👛',
      isDefault: true, createdAt: Date.now()
    }])
  }
  if (read(K.categories, null) === null) write(K.categories, seedCategories())
  ensureCategoryColors()
  if (read(K.bills, null) === null) write(K.bills, [])
  if (read(K.budgets, null) === null) write(K.budgets, {})
  if (read(K.todos, null) === null) write(K.todos, [])
  if (read(K.goals, null) === null) write(K.goals, [])
  if (read(K.parttime, null) === null) write(K.parttime, [])
  if (read(K.aa, null) === null) write(K.aa, [])
}

/* ---------- 用户资料 ---------- */
function getProfile() {
  return read(K.profile, {
    nickname: '同学', avatar: '🐯', monthlyAllowance: 150000, createdAt: Date.now()
  })
}
function saveProfile(patch) {
  const p = Object.assign({}, getProfile(), patch)
  write(K.profile, p)
  return p
}

/* ---------- 账本 ---------- */
function listBooks() {
  return read(K.books, [])
}
function getBook(id) {
  const list = listBooks()
  for (let i = 0; i < list.length; i++) if (list[i].id === id) return list[i]
  return list[0]
}
function getDefaultBook() {
  const list = listBooks()
  for (let i = 0; i < list.length; i++) if (list[i].isDefault) return list[i]
  return list[0]
}
function addBook(name, icon) {
  const list = listBooks()
  const book = { id: U.uid(), name: name, icon: icon || '📒', isDefault: false, createdAt: Date.now() }
  list.push(book)
  write(K.books, list)
  return book
}
function updateBook(id, patch) {
  const list = listBooks().map(function (b) {
    return b.id === id ? Object.assign({}, b, patch) : b
  })
  write(K.books, list)
}
function deleteBook(id) {
  const target = getBook(id)
  if (!target || target.isDefault) return { ok: false, msg: '默认账本不可删除' }
  const fallback = getDefaultBook()
  const bills = read(K.bills, []).map(function (b) {
    if (b.bookId === id) return Object.assign({}, b, { bookId: fallback.id })
    if (b.fromBookId === id) return Object.assign({}, b, { fromBookId: fallback.id })
    if (b.toBookId === id) return Object.assign({}, b, { toBookId: fallback.id })
    return b
  })
  write(K.bills, bills)
  write(K.books, listBooks().filter(function (b) { return b.id !== id }))
  return { ok: true }
}
function bookBillCount(id) {
  return read(K.bills, []).filter(function (b) {
    return b.bookId === id || b.fromBookId === id || b.toBookId === id
  }).length
}
function currentBookId() {
  const meta = read(K.meta, {})
  const books = listBooks()
  const cur = books.filter(function (b) { return b.id === meta.currentBookId })[0]
  return cur ? cur.id : getDefaultBook().id
}
function setCurrentBook(id) {
  const meta = read(K.meta, {})
  meta.currentBookId = id
  write(K.meta, meta)
}

/* ---------- 分类 ---------- */
function listCategories(type) {
  const list = read(K.categories, [])
  return type ? list.filter(function (c) { return c.type === type }) : list
}
function getCategory(id) {
  const list = listCategories()
  for (let i = 0; i < list.length; i++) if (list[i].id === id) return list[i]
  return null
}
function addCategory(name, icon, type, color) {
  const list = listCategories()
  // 未指定颜色时按规范色板轮换分配
  const palette = ['#FF6B6B', '#FF9F43', '#FFD166', '#2ECC71', '#4ECDC4', '#2B7CFF', '#A78BFA', '#F472B6']
  const cat = {
    id: U.uid(), name: name, icon: icon || 'plus', type: type || 'expense',
    color: color || (type === 'income' ? '#2ECC71' : palette[list.length % palette.length]),
    group: '自定义', usage: 0, enabled: true, custom: true
  }
  list.push(cat)
  write(K.categories, list)
  return cat
}
function updateCategory(id, patch) {
  write(K.categories, listCategories().map(function (c) {
    return c.id === id ? Object.assign({}, c, patch) : c
  }))
}
function deleteCategory(id) {
  write(K.categories, listCategories().filter(function (c) { return c.id !== id }))
}
// 按使用频率排序（常用置顶）
function sortByUsage(list) {
  return list.slice().sort(function (a, b) { return (b.usage || 0) - (a.usage || 0) })
}
function incCategoryUsage(id) {
  write(K.categories, listCategories().map(function (c) {
    return c.id === id ? Object.assign({}, c, { usage: (c.usage || 0) + 1 }) : c
  }))
}

/* ---------- 账单 ---------- */
function listBills(filter) {
  filter = filter || {}
  let list = read(K.bills, []).slice()
  if (filter.date) list = list.filter(function (b) { return b.date === filter.date })
  if (filter.month) list = list.filter(function (b) { return String(b.date).indexOf(filter.month) === 0 })
  if (filter.bookId) {
    list = list.filter(function (b) {
      return b.type === 'transfer' || b.bookId === filter.bookId
    })
  }
  if (filter.type) list = list.filter(function (b) { return b.type === filter.type })
  if (filter.categoryId) list = list.filter(function (b) { return b.categoryId === filter.categoryId })
  if (filter.min != null) list = list.filter(function (b) { return b.amount >= filter.min })
  if (filter.max != null) list = list.filter(function (b) { return b.amount <= filter.max })
  if (filter.keyword) {
    const kw = String(filter.keyword).trim()
    if (kw) {
      list = list.filter(function (b) {
        return (b.note || '').indexOf(kw) >= 0 || (Math.abs(b.amount) / 100).toFixed(2).indexOf(kw) >= 0
      })
    }
  }
  list.sort(function (a, b) {
    if (a.date !== b.date) return a.date < b.date ? 1 : -1
    return (b.createdAt || 0) - (a.createdAt || 0)
  })
  return list
}
function getBill(id) {
  const list = read(K.bills, [])
  for (let i = 0; i < list.length; i++) if (list[i].id === id) return list[i]
  return null
}
function addBill(bill) {
  const list = read(K.bills, [])
  const b = Object.assign({ id: U.uid(), createdAt: Date.now() }, bill)
  list.push(b)
  write(K.bills, list)
  if (b.type === 'expense' || b.type === 'income') incCategoryUsage(b.categoryId)
  return b
}
function updateBill(id, patch) {
  write(K.bills, read(K.bills, []).map(function (b) {
    return b.id === id ? Object.assign({}, b, patch) : b
  }))
}
function deleteBill(id) {
  write(K.bills, read(K.bills, []).filter(function (b) { return b.id !== id }))
}
function deleteBills(ids) {
  const set = {}
  ids.forEach(function (i) { set[i] = true })
  write(K.bills, read(K.bills, []).filter(function (b) { return !set[b.id] }))
}
function updateBillsCategory(ids, categoryId) {
  const set = {}
  ids.forEach(function (i) { set[i] = true })
  write(K.bills, read(K.bills, []).map(function (b) {
    return set[b.id] ? Object.assign({}, b, { categoryId: categoryId }) : b
  }))
}

/* ---------- 预算 ---------- */
function getBudget(ym) {
  const all = read(K.budgets, {})
  if (all[ym]) return all[ym]
  return { total: getProfile().monthlyAllowance, categories: [], carryOver: false, auto: true }
}
function saveBudget(ym, patch) {
  const all = read(K.budgets, {})
  all[ym] = Object.assign({}, getBudget(ym), patch, { auto: false })
  write(K.budgets, all)
  return all[ym]
}
// 生效预算 = 设置值 + （开启结余结转且上月有结余时）上月结余
function effectiveBudget(ym) {
  const b = getBudget(ym)
  if (!b.carryOver) return b
  const prevYm = U.addMonths(ym, -1)
  const prev = getBudget(prevYm)
  const prevSpent = monthSummary(prevYm).expense
  const surplus = prev.total - prevSpent
  if (surplus > 0) {
    return Object.assign({}, b, { total: b.total + surplus, carried: surplus })
  }
  return b
}
function lastMonthSurplus(ym) {
  const prevYm = U.addMonths(ym, -1)
  const prev = getBudget(prevYm)
  const prevSpent = monthSummary(prevYm).expense
  const s = prev.total - prevSpent
  return s > 0 ? s : 0
}

/* ---------- 待办 ---------- */
function listTodos() {
  return read(K.todos, [])
}
function getTodo(id) {
  return listTodos().filter(function (t) { return t.id === id })[0] || null
}
function addTodo(content, priority, due) {
  const list = listTodos()
  const todo = {
    id: U.uid(), content: content, priority: priority || 'mid',
    due: due || '', done: false, createdAt: Date.now()
  }
  list.push(todo)
  write(K.todos, list)
  return todo
}
function updateTodo(id, patch) {
  write(K.todos, listTodos().map(function (t) {
    return t.id === id ? Object.assign({}, t, patch) : t
  }))
}
function toggleTodo(id) {
  const t = listTodos().filter(function (x) { return x.id === id })[0]
  if (t) updateTodo(id, { done: !t.done })
}
function deleteTodo(id) {
  write(K.todos, listTodos().filter(function (t) { return t.id !== id }))
}
// 上移 / 下移一位
function moveTodo(id, dir) {
  const list = listTodos()
  const idx = list.findIndex(function (t) { return t.id === id })
  if (idx < 0) return
  const target = idx + dir
  if (target < 0 || target >= list.length) return
  const tmp = list[idx]
  list[idx] = list[target]
  list[target] = tmp
  write(K.todos, list)
}

/* ---------- 储蓄目标 ---------- */
function listGoals() {
  return read(K.goals, [])
}
function addGoal(name, target, monthly, icon) {
  const list = listGoals()
  const goal = {
    id: U.uid(), name: name, target: target, saved: 0,
    monthly: monthly || 0, icon: icon || '🎯', createdAt: Date.now()
  }
  list.push(goal)
  write(K.goals, list)
  return goal
}
function updateGoal(id, patch) {
  write(K.goals, listGoals().map(function (g) {
    return g.id === id ? Object.assign({}, g, patch) : g
  }))
}
function deleteGoal(id) {
  write(K.goals, listGoals().filter(function (g) { return g.id !== id }))
}
function depositGoal(id, cents) {
  const g = listGoals().filter(function (x) { return x.id === id })[0]
  if (!g) return
  updateGoal(id, { saved: Math.min(g.target, g.saved + cents) })
}

/* ---------- 兼职收入 ---------- */
function listPartTime() {
  return read(K.parttime, []).slice().sort(function (a, b) {
    return (b.createdAt || 0) - (a.createdAt || 0)
  })
}
function addPartTime(amount, type, date, note) {
  const list = read(K.parttime, [])
  const rec = { id: U.uid(), amount: amount, type: type, date: date, note: note || '', createdAt: Date.now() }
  list.push(rec)
  write(K.parttime, list)
  return rec
}
function deletePartTime(id) {
  write(K.parttime, read(K.parttime, []).filter(function (p) { return p.id !== id }))
}

/* ---------- AA 分账记录 ---------- */
function listAA() {
  return read(K.aa, []).slice().sort(function (a, b) {
    return (b.createdAt || 0) - (a.createdAt || 0)
  })
}
function addAA(total, people, perPerson, date) {
  const list = read(K.aa, [])
  const rec = {
    id: U.uid(), total: total, people: people,
    perPerson: perPerson, date: date, createdAt: Date.now()
  }
  list.push(rec)
  write(K.aa, list)
  return rec
}

/* ---------- 统计 ---------- */
function monthSummary(ym) {
  const list = listBills({ month: ym })
  let expense = 0
  let income = 0
  let count = 0
  list.forEach(function (b) {
    if (b.type === 'expense') expense += b.amount
    else if (b.type === 'income') income += b.amount
    else return
    count += 1
  })
  return { expense: expense, income: income, balance: income - expense, count: count }
}
function categoryTotals(ym, type) {
  const list = listBills({ month: ym, type: type })
  const map = {}
  list.forEach(function (b) {
    map[b.categoryId] = (map[b.categoryId] || 0) + b.amount
  })
  return listCategories(type).map(function (c) {
    return { id: c.id, name: c.name, icon: c.icon, color: c.color, amount: map[c.id] || 0 }
  }).filter(function (x) { return x.amount > 0 })
    .sort(function (a, b) { return b.amount - a.amount })
}
// 当月各分类支出笔数 map: { catId: 3 }
function categoryCounts(ym, type) {
  const map = {}
  listBills({ month: ym, type: type || 'expense' }).forEach(function (b) {
    map[b.categoryId] = (map[b.categoryId] || 0) + 1
  })
  return map
}
// 当月每日支出 map: { '2026-10-01': 3500 }
function dailyExpenseMap(ym) {
  const map = {}
  listBills({ month: ym, type: 'expense' }).forEach(function (b) {
    map[b.date] = (map[b.date] || 0) + b.amount
  })
  return map
}
// 当月每日收入 map: { '2026-10-01': 1500 }
function dailyIncomeMap(ym) {
  const map = {}
  listBills({ month: ym, type: 'income' }).forEach(function (b) {
    map[b.date] = (map[b.date] || 0) + b.amount
  })
  return map
}
// 近 n 个月支出趋势（含当月）
function trendExpense(n) {
  const arr = []
  const cur = U.monthStr()
  for (let i = n - 1; i >= 0; i--) {
    const ym = U.addMonths(cur, -i)
    arr.push({ ym: ym, expense: monthSummary(ym).expense })
  }
  return arr
}
// 本周（周一为首日）与上周支出
function weekCompare() {
  const today = new Date()
  const dow = (today.getDay() + 6) % 7 // 周一=0
  const monday = U.dateStr(new Date(today.getFullYear(), today.getMonth(), today.getDate() - dow))
  const lastMonday = U.addDays(monday, -7)
  const lastSunday = U.addDays(monday, -1)
  let cur = 0
  let prev = 0
  read(K.bills, []).forEach(function (b) {
    if (b.type !== 'expense') return
    if (b.date >= monday && b.date <= U.dateStr(today)) cur += b.amount
    else if (b.date >= lastMonday && b.date <= lastSunday) prev += b.amount
  })
  return { monday: monday, cur: cur, prev: prev }
}
// 本周分类 TOP3
function weekTopCategories() {
  const wc = weekCompare()
  const today = U.dateStr(new Date())
  const map = {}
  read(K.bills, []).forEach(function (b) {
    if (b.type !== 'expense') return
    if (b.date >= wc.monday && b.date <= today) {
      map[b.categoryId] = (map[b.categoryId] || 0) + b.amount
    }
  })
  const cats = listCategories('expense')
  return cats.map(function (c) {
    return { name: c.name, icon: c.icon, color: c.color, amount: map[c.id] || 0 }
  }).filter(function (x) { return x.amount > 0 })
    .sort(function (a, b) { return b.amount - a.amount })
    .slice(0, 3)
}
// 累计记账天数
function totalStat() {
  const bills = read(K.bills, [])
  const days = {}
  bills.forEach(function (b) { days[b.date] = true })
  return { billCount: bills.length, dayCount: Object.keys(days).length }
}

/* ---------- 演示数据 ---------- */
function seedDemoData() {
  const bills = read(K.bills, [])
  const cats = listCategories('expense').filter(function (c) { return c.enabled })
  if (!cats.length) return
  const profile = getProfile()
  const today = new Date()
  for (let m = 5; m >= 0; m--) {
    const d = new Date(today.getFullYear(), today.getMonth() - m, 1)
    const ym = U.monthStr(d)
    const dim = U.daysInMonth(ym)
    const maxDay = m === 0 ? today.getDate() : dim
    // 月初生活费
    bills.push({
      id: U.uid(), type: 'income', amount: profile.monthlyAllowance,
      categoryId: (listCategories('income').filter(function (c) { return c.name === '生活费' })[0] || {}).id,
      bookId: 'book_life', note: '本月生活费', date: ym + '-01', createdAt: Date.now() - m * 30 * 86400000
    })
    const n = 14 + Math.floor(Math.random() * 10)
    for (let i = 0; i < n; i++) {
      const day = 1 + Math.floor(Math.random() * maxDay)
      const cat = cats[Math.floor(Math.random() * cats.length)]
      const amount = 300 + Math.floor(Math.random() * 9000)
      bills.push({
        id: U.uid(), type: 'expense', amount: amount,
        categoryId: cat.id, bookId: 'book_life', note: '',
        date: ym + '-' + U.pad2(day),
        createdAt: Date.now() - m * 30 * 86400000 + i * 3600000
      })
    }
  }
  write(K.bills, bills)
  // 示例待办
  const todos = listTodos()
  if (!todos.length) {
    todos.push({ id: U.uid(), content: '晚上去图书馆还书', priority: 'high', due: U.dateStr(new Date()), done: false, createdAt: Date.now() })
    todos.push({ id: U.uid(), content: '统计本月餐饮支出', priority: 'mid', due: '', done: false, createdAt: Date.now() })
    todos.push({ id: U.uid(), content: '购买打印资料（论文）', priority: 'mid', due: U.addDays(U.dateStr(new Date()), 1), done: false, createdAt: Date.now() })
    write(K.todos, todos)
  }
  // 示例储蓄目标
  if (!listGoals().length) {
    addGoal('买一台笔记本电脑', 500000, 50000, '💻')
    updateGoal(listGoals()[0].id, { saved: 120000 })
  }
  // 示例兼职记录
  if (!listPartTime().length) {
    addPartTime(30000, '家教', U.addDays(U.dateStr(new Date()), -3), '初三数学 2 小时')
    addPartTime(20000, '校园代理', U.addDays(U.dateStr(new Date()), -10), '校园卡代理提成')
  }
}

/* ---------- 清空 ---------- */
function clearAll() {
  Object.keys(K).forEach(function (k) {
    try { wx.removeStorageSync(PREFIX + K[k]) } catch (e) {}
  })
  init()
}

module.exports = {
  init,
  getProfile,
  saveProfile,
  listBooks,
  getBook,
  getDefaultBook,
  addBook,
  updateBook,
  deleteBook,
  bookBillCount,
  currentBookId,
  setCurrentBook,
  listCategories,
  getCategory,
  addCategory,
  updateCategory,
  deleteCategory,
  sortByUsage,
  incCategoryUsage,
  listBills,
  getBill,
  addBill,
  updateBill,
  deleteBill,
  deleteBills,
  updateBillsCategory,
  getBudget,
  saveBudget,
  effectiveBudget,
  lastMonthSurplus,
  listTodos,
  getTodo,
  addTodo,
  updateTodo,
  toggleTodo,
  deleteTodo,
  moveTodo,
  listGoals,
  addGoal,
  updateGoal,
  deleteGoal,
  depositGoal,
  listPartTime,
  addPartTime,
  deletePartTime,
  listAA,
  addAA,
  monthSummary,
  categoryTotals,
  categoryCounts,
  dailyExpenseMap,
  dailyIncomeMap,
  trendExpense,
  weekCompare,
  weekTopCategories,
  totalStat,
  seedDemoData,
  clearAll
}
