/* 全局常量：预置分类、预算推荐比例、图表色板等（深色暗黑主题） */

/* 分类圆形底色板（深色背景下白线形图标的实色圆底，全部来自规范色系） */
var CAT_COLORS = {
  red: '#FF6B6B',      // 珊瑚红
  orange: '#FF9F43',   // 暖橙
  yellow: '#FFD166',   // 明黄
  green: '#2ECC71',    // 薄荷绿
  teal: '#4ECDC4',     // 青
  blue: '#2B7CFF',     // 克莱因蓝（品牌主色）
  sky: '#60A5FA',      // 天蓝
  purple: '#A78BFA',   // 紫
  violet: '#C084FC',   // 紫罗兰
  pink: '#F472B6',     // 粉
  deeporange: '#FB923C'
}

// 支出预置分类（校园场景）：icon 为 line-icon 组件图标名，color 为圆形底色
var PRESET_EXPENSE = [
  {
    group: '餐饮',
    items: [
      { name: '食堂', icon: 'rice', color: CAT_COLORS.red },
      { name: '外卖', icon: 'takeout', color: CAT_COLORS.orange },
      { name: '奶茶/咖啡', icon: 'tea', color: CAT_COLORS.pink },
      { name: '聚餐', icon: 'beer', color: CAT_COLORS.yellow },
      { name: '零食', icon: 'cookie', color: CAT_COLORS.deeporange }
    ]
  },
  {
    group: '学习',
    items: [
      { name: '教材', icon: 'book', color: CAT_COLORS.teal },
      { name: '打印资料', icon: 'print', color: CAT_COLORS.sky },
      { name: '网课', icon: 'laptop', color: CAT_COLORS.blue },
      { name: '报名费', icon: 'pen', color: CAT_COLORS.purple },
      { name: '文具', icon: 'pencil', color: CAT_COLORS.green }
    ]
  },
  {
    group: '生活',
    items: [
      { name: '日用品', icon: 'tissue', color: CAT_COLORS.yellow },
      { name: '洗护', icon: 'soap', color: CAT_COLORS.teal },
      { name: '理发', icon: 'scissors', color: CAT_COLORS.pink },
      { name: '医药费', icon: 'pill', color: CAT_COLORS.red }
    ]
  },
  {
    group: '交通',
    items: [
      { name: '公交/地铁', icon: 'bus', color: CAT_COLORS.blue },
      { name: '共享单车', icon: 'bike', color: CAT_COLORS.green },
      { name: '打车', icon: 'taxi', color: CAT_COLORS.orange },
      { name: '火车票', icon: 'train', color: CAT_COLORS.sky }
    ]
  },
  {
    group: '购物',
    items: [
      { name: '服饰', icon: 'shirt', color: CAT_COLORS.purple },
      { name: '数码配件', icon: 'headphone', color: CAT_COLORS.sky },
      { name: '护肤品', icon: 'lotion', color: CAT_COLORS.pink },
      { name: '网购', icon: 'cart', color: CAT_COLORS.teal },
      { name: '快递', icon: 'box', color: CAT_COLORS.deeporange }
    ]
  },
  {
    group: '娱乐',
    items: [
      { name: '电影', icon: 'movie', color: CAT_COLORS.violet },
      { name: '游戏充值', icon: 'game', color: CAT_COLORS.red },
      { name: '会员订阅', icon: 'tv', color: CAT_COLORS.blue },
      { name: '演唱会', icon: 'mic', color: CAT_COLORS.pink }
    ]
  }
]

// 收入预置分类
var PRESET_INCOME = [
  { name: '生活费', icon: 'wallet', color: CAT_COLORS.green },
  { name: '奖学金', icon: 'trophy', color: CAT_COLORS.yellow },
  { name: '助学金', icon: 'grad', color: CAT_COLORS.orange },
  { name: '兼职', icon: 'briefcase', color: CAT_COLORS.teal },
  { name: '红包', icon: 'redpacket', color: CAT_COLORS.red },
  { name: '退款', icon: 'refund', color: CAT_COLORS.sky },
  { name: '其他收入', icon: 'plus', color: CAT_COLORS.purple }
]

// 预算按比例推荐（PRD：餐饮 40%、学习 15%、生活 20% 等参考比例）
var BUDGET_RATIOS = [
  { name: '餐饮', ratio: 40 },
  { name: '学习', ratio: 15 },
  { name: '生活', ratio: 20 },
  { name: '交通', ratio: 8 },
  { name: '购物', ratio: 10 },
  { name: '娱乐', ratio: 7 }
]

// 图表色板（规范：品牌蓝/支出红/收入绿/辅助橙黄打底，深色背景高对比）
var CHART_COLORS = [
  '#2B7CFF', '#FF5B5B', '#2ECC71', '#FF9F43', '#FFD166',
  '#4ECDC4', '#A78BFA', '#F472B6', '#60A5FA', '#8492B0'
]

// 自定义分类可选线形图标（line-icon 图标名）
var CUSTOM_ICONS = [
  'rice', 'takeout', 'tea', 'beer', 'cookie', 'book', 'print', 'laptop',
  'pen', 'pencil', 'tissue', 'soap', 'scissors', 'pill', 'bus', 'bike',
  'taxi', 'train', 'shirt', 'headphone', 'lotion', 'cart', 'box', 'movie',
  'game', 'tv', 'mic', 'wallet', 'trophy', 'grad', 'briefcase', 'redpacket',
  'refund', 'plus', 'target', 'piggy', 'chart', 'home', 'bill', 'user',
  'calendar', 'filter', 'share', 'aa', 'asset'
]

// 待办优先级（深色友好）
var PRIORITIES = [
  { key: 'high', label: '高', color: '#FF5B5B' },
  { key: 'mid', label: '中', color: '#FF9F43' },
  { key: 'low', label: '低', color: '#6E7280' }
]

// 兼职类型
var PARTTIME_TYPES = ['家教', '实习', '校园代理', '其他']

// 首页校园快捷记账入口
var QUICK_CATEGORIES = ['食堂', '奶茶/咖啡', '打印资料', '快递']

// 账本可选 emoji（账本/储蓄目标图标保留 emoji 风格）
var EMOJI_ICONS = [
  '📒', '💰', '🎓', '💼', '❤️', '🎁', '🏆', '💻', '📱', '✈️',
  '🎯', '🐯', '🎂', '⚽', '🎵', '🏃', '☕', '🍀'
]

module.exports = {
  CAT_COLORS,
  PRESET_EXPENSE,
  PRESET_INCOME,
  BUDGET_RATIOS,
  CHART_COLORS,
  CUSTOM_ICONS,
  PRIORITIES,
  PARTTIME_TYPES,
  QUICK_CATEGORIES,
  EMOJI_ICONS
}
